import java.util.HashMap;

public class Main {

	public static void main(String[] args) {
		
		Conexao c = new Conexao();
		DatabaseColetor database = new DatabaseColetor(c);
		HashMap<Integer, Semente> hash = database.pegarSementes();
		System.out.println(" N� de sementes no banco : "+hash.size());
		ListaSementes.iniciar(hash);

		int porta = 12345;
		
		for (int i = 0; i < 19; i++)
		{
			Servidor servidor = new Servidor(i,porta+i);
			new Thread(servidor).start();
		}
		
		
	}

}
