

import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class Servidor implements Runnable 
{

	private ServerSocket servidor;
	private static String pasta = System.getProperty("user.home")+"\\Desktop\\Paginas\\";
	private int idservidor;
	
	public Servidor(int idservidor, int porta)
	{
		try
		{
			this.setIdservidor(idservidor);
			setServidor(new ServerSocket(porta));
			System.out.println("Porta "+porta+" aberta!");
			
		} catch (IOException e) 
		{
			System.out.println(" Erro abrindo socket do servidor !!");
			e.printStackTrace();
		}
	}
	
	public void run() 
	{
	   while(true)
	   {	
		   try 
		   {
			   Socket cliente = servidor.accept();
			   Link link = ListaSementes.getSemente(idservidor);
			   System.out.println("Nova conex�o com o cliente "
					+ cliente.getInetAddress().getHostAddress() + " Semente : "+link.getNome());
			   TrataCliente c = new TrataCliente(cliente, link);
			   new Thread(c).start();
		   } 
		   catch (IOException e) 
		   {
			System.out.println(" Erro aceitando socket cliente! ");
			e.printStackTrace();
		   }
	   }
	}
	
	public static void enviarLink(ObjectOutputStream cliente, Link url) 
	{
	 	try 
	 	{
			cliente.writeObject(url);
			cliente.flush();
			
		} catch (IOException e) 
	 	{
				System.out.println(" Erro enviando semente! ");
				e.printStackTrace();
		}
		
	}
	

	public ServerSocket getServidor()
	{
		return servidor;
	}

	public void setServidor(ServerSocket servidor)
	{
		this.servidor = servidor;
	}

	public static String getPasta() {
		return pasta;
	}

	public static void setPasta(String path) {
		pasta = path;
	}

	public int getIdservidor() {
		return idservidor;
	}

	public void setIdservidor(int idservidor) {
		this.idservidor = idservidor;
	}
}
