

/*
 * Pontificia Universidade Catolica de Minas Gerais
 * Ciencia da Computacao - 2016
 * Autor(a): Ana Carolina Conceicao de Jesus
 * 
 */

import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.Socket;


public class TrataCliente implements Runnable {

	private Socket cliente;
	private Link link;
	public TrataCliente(Socket cliente, Link link)
	{
		this.cliente = cliente;
		this.link = link;
	}

	public void run() {
		
		try 
		{
			Servidor.enviarLink(new ObjectOutputStream(cliente.getOutputStream()), link);
			
			while(true)
			{
				ReceberArquivoNoServidor.receberArquivo(cliente);
			}
		} 
		catch (IOException e) 
		{
			e.printStackTrace();
			try {
				cliente.close(); // fechar conexao com cliente
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		}
		
		
	}

	
	
}
