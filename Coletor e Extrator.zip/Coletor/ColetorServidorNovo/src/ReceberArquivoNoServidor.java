

/*
 * Pontificia Universidade Catolica de Minas Gerais
 * Ciencia da Computacao - 2016
 * Autor(a): Ana Carolina Conceicao de Jesus
 * 
 */

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.Socket;


public class ReceberArquivoNoServidor {
	public static void receberArquivo(Socket cliente) throws IOException
	{
	   	try
	   	{
	   		ObjectInputStream in = new ObjectInputStream(cliente.getInputStream());
			Arquivo arquivo = (Arquivo) in.readObject();
			
			System.out.println("######################################################################");
			System.out.println(" Arquivo Recebido de :"+cliente.getInetAddress().getHostAddress()+" Porta: "+cliente.getLocalPort());
			System.out.println("Salvando arquivo no Servidor no caminho: "+Servidor.getPasta()+arquivo.getNome());
			// gravar o arquivo em disco
			
			//System.out.println(arquivo.getConteudo());
			System.out.println("########################################################################");
			
			File file = new File(Servidor.getPasta()+arquivo.getNome());
			FileWriter gravar = new FileWriter(file);
			gravar.write(arquivo.getConteudo());
			gravar.flush();
			gravar.close();
			
		}
	   	catch (ClassNotFoundException e)
	   	{
			System.out.println("Erro lendo arquivo - ReceberArquivoNoServidor - receberArquivoServidor");
			e.printStackTrace();
		}
	    
		
	}
	
}
