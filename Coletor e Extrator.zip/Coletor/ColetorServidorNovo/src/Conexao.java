



import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexao {
	
	private static Connection con;
	
	public Conexao()
	{
		String ip = "127.0.0.1";
		criarConexao("jdbc:postgresql://"+ip+":5432/Coletor", "postgres",
				"postgres");
	}
	public static void criarConexao(String endereco, String user, String senha) {
		try {
			Class.forName("org.postgresql.Driver");

			try {
				con = DriverManager.getConnection(endereco,user,senha);
			} catch (SQLException e) {
			
				e.printStackTrace();
			}

			System.out.println("Conex�o realizada com sucesso.");

		} catch (ClassNotFoundException e) {
		
			e.printStackTrace();
		}
	}
	
	public  Connection getConnection(){

	     return con;

	 }

}
