

import java.util.HashMap;

public interface TransacoesDatabaseColetor {

	public abstract boolean inserirLink (String nome, String url);
	public abstract boolean consultarLink(String url);
	public abstract boolean consultarCampoDataColeta(String url);
	public abstract String pegarIdLink(String url);
	public abstract boolean setDataColeta(String url, String data);
	public abstract boolean setIP(String url, String ip);
	public abstract HashMap<Integer, Semente> pegarSementes();
	
}
