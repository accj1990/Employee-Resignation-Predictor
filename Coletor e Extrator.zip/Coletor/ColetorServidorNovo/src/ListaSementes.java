

/*
 * Pontificia Universidade Catolica de Minas Gerais
 * Ciencia da Computacao - 2016
 * Autor(a): Ana Carolina Conceicao de Jesus
 * 
 */
import java.util.HashMap;


public class ListaSementes {

	private static HashMap<Integer, Link> sementes;
	public static  int contador = 0;
	public static int cont = 0;  
	
	public static void iniciar(HashMap<Integer,Semente> hash)
	{
		sementes = new HashMap<Integer, Link>();
		lerSementes(hash);
	}
	
	public static void lerSementes(HashMap<Integer,Semente> hash)
	{
		Semente semente;
		for(Integer e: hash.keySet())
		{
			semente = hash.get(e);
			sementes.put(contador++, semente);
		}
	}
	
	public static void imprimirSementes()
	{
		for(Integer e: sementes.keySet())
		{
			System.out.println(e + " "+sementes.get(e).getNome());
			
		}
	}
	
	public static Link getSemente(int id) {
		return sementes.get(id+cont++);
	}

}
