

/*
 * Pontificia Universidade Catolica de Minas Gerais
 * Ciencia da Computacao - 2016
 * Autor(a): Ana Carolina Conceicao de Jesus
 * 
 */

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;

public class DatabaseColetor implements TransacoesDatabaseColetor{

	private Conexao conexao;
	
	public DatabaseColetor(Conexao con)
	{
		setConexao(con);
	}
	
	public boolean updatePais(int codigo, String pais) {
        boolean update = false;
        try {
            String sql = "update pessoa set pais = '"+pais+"' where id = "+codigo+";";
            Connection c = conexao.getConnection();
            PreparedStatement ps = c.prepareStatement(sql);
            update  = ps.execute();
 
        } catch (SQLException e) {
            e.printStackTrace();
        }
      return update;
    }
	
	/* insere um link no banco de dados ok */
	public boolean inserirLink(String nome, String url) {
		boolean inserir = false;
		try {
			String sql = "INSERT INTO Pessoa VALUES (DEFAULT,'"+nome+"','"+url+"', DEFAULT, DEFAULT)";
			Connection c = conexao.getConnection();
			PreparedStatement ps = c.prepareStatement(sql);
			inserir = ps.execute();

		} catch (SQLException e) {
			e.printStackTrace();
		}
      return inserir;
	}

	/* retorna o codigo atribuido a pagina quando ela foi adicionada [usado para salvar o html] ok*/
	public String pegarIdLink(String url) {
		String nomArq = "";
		try {
			Statement stm = conexao.getConnection().createStatement();
			ResultSet consulta = stm.executeQuery("SELECT id, nome from Pessoa where url = '"+url+"'");
			
			if(consulta.next())
			{
			  String codigo = consulta.getString("id");
			  String nome = consulta.getString("nome");
			  nomArq = codigo +" - "+nome;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("Erro pegando ID no BD!!!");
			
		}
		
		return nomArq;
	}
	
	public String pegarMaquina(String url) {
		String ipmaquina = "";
		try {
			Statement stm = conexao.getConnection().createStatement();
			ResultSet consulta = stm.executeQuery("SELECT maquina from Pessoa where url = '"+url+"'");
			
			if(consulta.next())
			{
			  ipmaquina = consulta.getString("maquina");
			}
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("Erro pegando IP de maquina no BD!!!");
			
		}
		
		return ipmaquina;
	}

	
	

	/* atualiza o campo data da coleta ok */
	public boolean setDataColeta(String url, String data) {
		boolean atualizado = false;
		try 
		{
			String consultasql = "SELECT data_coleta from Pessoa where url = '"+url+"'";
			Connection c = conexao.getConnection();
			PreparedStatement ps = c.prepareStatement(consultasql);
			
			ResultSet resultado = ps.executeQuery();
			
			if(resultado.next())
			{
				resultado.getString("data_coleta");
				if(resultado.wasNull())
				{
					String atualizasql = "UPDATE Pessoa SET data_coleta = '"+data+"' where url = '"+url+"'";
					PreparedStatement sp = c.prepareStatement(atualizasql);
					atualizado = true;
					sp.execute();
					
				}
				
			}
			
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}		
	
		return atualizado;
	}

	/* atualiza o campo ip ok */
	public boolean setIP(String url, String ip) {
		boolean atualizado = false;
		try 
		{
			String consultasql = "SELECT maquina from Pessoa where url = '"+url+"'";
			Connection c = conexao.getConnection();
			PreparedStatement ps = c.prepareStatement(consultasql);
			
			ResultSet resultado = ps.executeQuery();
			
			if(resultado.next())
			{
				resultado.getString("maquina");
				if(resultado.wasNull())
				{
					String atualizasql = "UPDATE Pessoa SET maquina = '"+ip+"' where url = '"+url+"'";
					PreparedStatement sp = c.prepareStatement(atualizasql);
					atualizado = sp.execute();
					
				}
				
			}
			
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}		
	
		return atualizado;
	}

	/* consulta se o link esta no banco de dados */
	public boolean consultarLink(String url) {
		boolean teste = false;
		try 
		{
			Statement stm = conexao.getConnection().createStatement();
			ResultSet consulta = stm.executeQuery("SELECT id from pessoa where url = '"+url+"'");
			
			if(consulta.next())
			{
				teste = true;
			}
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
			System.out.println("Erro consultando no BD!!!");
		}
		
		return teste;
	}


	/* verifica se a data da coleta esta null ou nao */
	public boolean consultarCampoDataColeta(String url) {
		boolean teste = false;
		try 
		{
			Connection c = conexao.getConnection();
			String sql = "SELECT data_coleta from Pessoa where url = '"+url+"'";
			PreparedStatement ps =  c.prepareStatement(sql);
			ResultSet consulta = ps.executeQuery();
			
			if(consulta.next())
			{
				consulta.getString("data_coleta");
				if(consulta.wasNull())
				{
					teste = true;
				}
				else
				{
					teste = false;
				}
			}
			
		}
		catch (SQLException e) 
		{
			e.printStackTrace();
			System.out.println("Erro consultando no BD!!!");
		}
		
		return teste;
	}

	/* retorna um hashmap com todas as urls presentes no banco que ainda n�o foram baixadas */
	public HashMap<Integer, Semente> pegarSementes() {
		HashMap<Integer, Semente> hash = null;
		
		try {
			Connection c = conexao.getConnection();
			String sql = "SELECT *from Pessoa where data_coleta is null and maquina is null";
			PreparedStatement ps = c.prepareStatement(sql);
			ResultSet consulta = ps.executeQuery();			
			hash = new HashMap<Integer, Semente>();
			Semente link = null;
			
			Integer id;
			String nome;
			String url;
			while(consulta.next())
			{
			  id = Integer.parseInt(consulta.getString("id"));
			  nome = consulta.getString("nome");
			  url = consulta.getString("url");
			  
			  link = new Semente(nome, url);
			  hash.put(id, link);
			}
		
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("Erro recuperando sementes no BD!!!");
			
		}
		
		return hash;
	}
	
	public HashMap<Integer, Link> verificar() {
		HashMap<Integer, Link> hash = null;
		
		try {
			Connection c = conexao.getConnection();
			String sql = "SELECT *from Pessoa where data_coleta is not null and maquina is not null";
			PreparedStatement ps = c.prepareStatement(sql);
			ResultSet consulta = ps.executeQuery();			
			hash = new HashMap<Integer, Link>();
			Link link = null;
			
			Integer id;
			String nome;
			String url;
			while(consulta.next())
			{
			  id = Integer.parseInt(consulta.getString("id"));
			  nome = consulta.getString("nome");
			  url = consulta.getString("url");
			  
			  link = new Semente(nome, url);
			  hash.put(id, link);
			}
		
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("Erro recuperando sementes no BD!!!");
			
		}
		
		return hash;
	}
	
	public boolean corrigirData(String url) {
		boolean atualizado = false;
		try 
		{
			String consultasql = "SELECT data_coleta from Pessoa where url = '"+url+"'";
			Connection c = conexao.getConnection();
			PreparedStatement ps = c.prepareStatement(consultasql);
			
			ResultSet resultado = ps.executeQuery();
			
			if(resultado.next())
			{
				resultado.getString("data_coleta");
				
				String atualizasql = "UPDATE Pessoa SET data_coleta = DEFAULT where url = '"+url+"'";
				PreparedStatement sp = c.prepareStatement(atualizasql);
				atualizado = sp.execute();
			}
			
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}		
	
		return atualizado;
	}
	
	public boolean corrigirMaquina(String url) {
		boolean atualizado = false;
		try 
		{
			String consultasql = "SELECT maquina from Pessoa where url = '"+url+"'";
			Connection c = conexao.getConnection();
			PreparedStatement ps = c.prepareStatement(consultasql);
			
			ResultSet resultado = ps.executeQuery();
			
			if(resultado.next())
			{
				resultado.getString("maquina");
				String atualizasql = "UPDATE Pessoa SET maquina = DEFAULT where url = '"+url+"'";
				PreparedStatement sp = c.prepareStatement(atualizasql);
				atualizado = sp.execute();
			}
			
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}		
	
		return atualizado;
	}
	
	
	public Conexao getConexao() {
		return conexao;
	}

	public void setConexao(Conexao conexao) {
		this.conexao = conexao;
	}
}
