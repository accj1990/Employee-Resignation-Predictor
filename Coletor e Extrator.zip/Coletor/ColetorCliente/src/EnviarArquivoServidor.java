import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.Scanner;


public class EnviarArquivoServidor {

	public static void enviarArquivoServidor(Socket cliente, Arquivo arquivo) throws IOException
	{
		ObjectOutputStream out = new ObjectOutputStream(cliente.getOutputStream());
	    out.writeObject(arquivo);	  
	    System.out.println("Conclu�do!");
	}
	
	@SuppressWarnings("resource")
	public static Arquivo lerArquivo(String path)
	{
		String nome="";
		String conteudo="";
		
		File file = new File(path+".html");
		
		Scanner in;
		try 
		{
			nome = file.getName();
			in = new Scanner(file);
			while(in.hasNext())
			{
				conteudo+=in.nextLine();
			}
		} catch (FileNotFoundException e) 
		{

			e.printStackTrace();
		}
		
		System.out.println("Lendo Arquivo ...");
		
		Arquivo arquivo = new Arquivo(nome, conteudo);
		return arquivo;
	}
}
