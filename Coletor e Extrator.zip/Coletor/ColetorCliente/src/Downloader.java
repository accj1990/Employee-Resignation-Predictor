
import java.io.BufferedReader;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.GregorianCalendar;
import java.util.HashMap;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class Downloader {

	static String path = System.getProperty("user.home")+"\\Desktop\\PaginasClientes\\";
	
    public static void baixarpage
	             (String nomearq,String link) throws Exception {
		
    	String s = path+ nomearq+ ".html";
		URL url;
		InputStream is = null;
		BufferedReader br = null;
		String line="";
		File html = new File(s);
		
		FileWriter gravar = null;
		url = new URL(link);
		is = url.openStream();
		
		System.out.println("Coletando o(a): "+nomearq + " "+getHora());
		
		br = new BufferedReader(new InputStreamReader(is));
		gravar = new FileWriter(html);
		
		while ((line = br.readLine()) != null) {
			gravar.write(line);
		}
	
		is.close();
		br.close();
		gravar.close();
        
	}
   

	@SuppressWarnings("null")
	public static HashMap<String,String> extrailinks
							(String nome)  {
		
		File docinput = new File(path+nome+".html");
		HashMap<String, String> linksextraidos = null;
		
		Document doc = null;

		if(docinput.exists()){
			Elements li = null;
			Element div;
			
			
			try {
				doc = Jsoup.parse(docinput, "UTF-8");
				div = doc.select("div.browse-map").last();	
				
			} catch (IOException e1) {
			
				e1.printStackTrace();
				div = doc.select("div.insights-browse-map").last();
			
			}
			
			if(div != null){
				li = div.select("li");
			

			String nome_prox = "";
			String url_prox = "";
			String[] array;
			linksextraidos = new HashMap<String, String>();
		 if (li != null){
			for (Element e : li) {
				nome_prox = "";
				url_prox = "";
				nome_prox = e.select("div").select("h4").last().text();
				nome_prox = removeCharEstranho(nome_prox);
				url_prox = e.select("div").select("h4").select("a").last().attr("href");

				if(url_prox.contains("https://")){
					nome_prox = tratarString(nome_prox);
		      
              		array = new String[2];
              		array[0] = nome_prox;
              		array[1] = url_prox;
			  
              		if(!HashVisitados.contains(array[1])){
              			linksextraidos.put(array[0], array[1]);
              		}
			  
				}
		
			}
		  }
		}
	  }
	  
		return linksextraidos;
	}
	
	public static String tratarString(String nome_prox)
	{
		nome_prox = nome_prox.replaceAll("[����]", "a");
		nome_prox = nome_prox.replaceAll("[���]", "e");
		nome_prox = nome_prox.replaceAll("[��]", "i");
		nome_prox = nome_prox.replaceAll("[����]", "o");
		nome_prox = nome_prox.replaceAll("[�]", "u");
		nome_prox = nome_prox.replaceAll("[�]", "c");
		nome_prox = nome_prox.replaceAll("[����]", "A");
		nome_prox = nome_prox.replaceAll("[���]", "E");
		nome_prox = nome_prox.replaceAll("[��]", "I");
		nome_prox = nome_prox.replaceAll("[����]", "O");
  		nome_prox = nome_prox.replaceAll("[�]", "U");
  		nome_prox = nome_prox.replaceAll("[�]", "C");
  		nome_prox = nome_prox.replaceAll("[^\\p{ASCII}]", "");
  		nome_prox = nome_prox.replaceAll("[^A-Za-z0-9]", " ");
		
		return nome_prox;
	}
	
	public static String getHora() {  
		  
		StringBuilder sb = new StringBuilder();  
		GregorianCalendar d = new GregorianCalendar();  
		  
		sb.append( d.get( GregorianCalendar.HOUR_OF_DAY ) );  
		sb.append( ":" );  
		sb.append( d.get( GregorianCalendar.MINUTE ) );  
		sb.append( ":" );  
		sb.append( d.get( GregorianCalendar.SECOND ) );  
		  
		return sb.toString();  
	}
	public static String removeCharEstranho(String nome_prox) {
		String novaString = "";
		for (int i = 0; i < nome_prox.length(); i++) {
			if (nome_prox.charAt(i) != '?') {
				novaString += nome_prox.charAt(i);
			}else{
				novaString+='A';
			}
			
		}
		return novaString;
	}

}
