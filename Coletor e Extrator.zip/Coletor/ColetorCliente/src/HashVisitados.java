

import java.util.HashMap;

public class HashVisitados {

	private static HashMap<String, String> visitados;
	
	public static void iniciar()
	{
		visitados = new HashMap<String, String>();
	}
	
	synchronized public static void inserir(String nome, String link)
	{
		if(!visitados.containsValue(link)) // chaves podem ser repetidas mas os links nao
			visitados.put(nome, link);
	}
	
	synchronized public static boolean contains(String link)
	{
		return (visitados.containsValue(link))? true:false;
	}
	
	synchronized public static boolean isNull()
	{
		return (visitados == null)?true:false;
	}
	
	synchronized public static boolean isEmpty()
	{
		return (visitados.size()== 0)? true:false;
	}
	
	synchronized public static void imprimir()
	{
		for(String e : visitados.keySet())
		{
			System.out.println(" "+visitados.get(e));
		}
	}
	
}
