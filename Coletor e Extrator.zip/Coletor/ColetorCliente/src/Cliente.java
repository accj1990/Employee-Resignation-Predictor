/*
 * Pontificia Universidade Catolica de Minas Gerais
 * Ciencia da Computa��o - 2015
 * Autor: Ana Carolina Conceicao de Jesus
 * 
 * */

import java.io.File;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.Socket;
import java.net.UnknownHostException;

public class Cliente 
{
  private static Socket cliente;
 
  public static void main(String [] args)
           throws UnknownHostException, IOException {
    
	 cliente = new Socket("127.0.0.1", 12356); // configurar o ip do servidor e a porta
	 //cliente = new Socket("201.17.228.208", 12356); 
	  
     System.out.println("O cliente se conectou ao servidor!");
     
     ObjectInputStream in = new ObjectInputStream(cliente.getInputStream());
     Link link = null;
  
     criarDiretorio(); // criar diretorio na area de trabalho
     
     while (true) 
     {
       try 
       {
    	  link = (Link) in.readObject();
			 
    	  System.out.println(" ###### SEMENTE RECEBIDA DO SERVIDOR ##### ");
		  System.out.println(" ###### NOME : "+link.getNome()+" ######## ");
		  System.out.println(" ###### URL: "+link.getLink()+"   ######## ");
		  System.out.println(" ######################################### ");
		  
		  Coletor c = new Coletor(cliente,link);
		  GerenciarColetor gc = new GerenciarColetor(c);
		  new Thread(c).start();
		  new Thread(gc).start();
	      
	   }
	   catch (ClassNotFoundException e) 
       {	
		 e.printStackTrace();
		 in.close();
	     cliente.close();
	   }
     
    }
    
     
   }

   public static void criarDiretorio()
   {
	   File diretorio = new File(System.getProperty("user.home")+"\\Desktop\\PaginasClientes\\");
	   if(!diretorio.exists())
	   {
		   diretorio.mkdir();
	   }
   }
  
   public static Socket getCliente()
   {
	   return cliente;
   }

 }