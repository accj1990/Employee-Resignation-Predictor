

/* 
 * Classe Adaptada
 * Fonte: http://www.guj.com.br/t/pegando-ip-local-e-pegando-ip-externo/86910 [Forum]
 * Data: 26/12/2015
 * Autor: andy11x
 *  
 * */


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PegarIP {

	public static String pegarIp()
	{		
		String ipexterno = "";
		String linhas = null;
		Matcher m;
		URL url;
		try {
			url = new URL(VerificarSite.verificarSite());
			HttpURLConnection conexao;
			try {
				conexao = (HttpURLConnection) url.openConnection();
				BufferedReader buffer = new BufferedReader(new InputStreamReader(conexao.getInputStream()));
				Pattern pega = Pattern.compile("[0-9]{1,3}[.-]{1}[0-9]{1,3}[.-]{1}[0-9]{1,3}[.-]{1}[0-9]{1,3}");
				while((linhas = buffer.readLine()) != null){
					m = pega.matcher(linhas);
					while(m.find()){
						ipexterno = m.group();
					  }
				  }
				buffer.close();
				conexao.disconnect();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return ipexterno;
	}

}
