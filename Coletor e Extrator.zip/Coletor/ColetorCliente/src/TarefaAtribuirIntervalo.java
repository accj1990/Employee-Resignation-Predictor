import java.util.Date;
import java.util.GregorianCalendar;
import java.util.TimerTask;


public class TarefaAtribuirIntervalo extends TimerTask{

	private Coletor c;
	
	public TarefaAtribuirIntervalo(Coletor c)
	{
		this.c = c;
	}
	
	
 	/*
 	 * atribuir melhor intervalo baseado na hora da coleta
 	 * manha - 06h a 12h --------> 5000 - 90000 - 5s a 1min e 30s
 	 * tarde - 13h a 17h --------> 5000 - 420000 5s a 
 	 * noite - 18h a 23h --------> 10000 - 500000
 	 * madrugada - 00h a 05h ----> 60000 - 600000
 	 *  
 	 */
	public void atribuirIntervalo(Coletor c)
	{
		System.out.println(" ### Atribuindo intervalo de coleta ###");
		GregorianCalendar gc = new GregorianCalendar();
	    Date data = gc.getTime();
	    
	    @SuppressWarnings("deprecation")
		int hora = data.getHours();
	    
	    if (hora >= 6 && hora <= 12)
	    {
	    	c.setA(5000);
	    	c.setB(90000);
	    }
	    else if (hora >= 13 && hora <= 17)
	    {
	    	c.setA(5000);
	    	c.setB(420000);
	    }
	    else if (hora >= 18 && hora <= 23)
	    {
	    	c.setA(10000);
	    	c.setB(500000);
	    }
	    else
	    {
	    	c.setA(60000);
	    	c.setB(600000);
	    }
		
	}

	public void run() {
		if (!c.isDormir())
		{
			atribuirIntervalo(c);
		}
	}

}
