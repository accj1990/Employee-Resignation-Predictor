/* 
 * Pontificia Universidade Catolica de Minas Gerais
 * Ciencia da Computacao - 2016
 * Ana Carolina Conceicao de Jesus
 * 
 * */


public class GerarTempoAleatorio {

	// Gera um tempo entre 5s e 1min e 30s (intervalo entre as coletas)
	public static long gerarTempo(long a, long b)
	{
		long tempo = Math.abs(((long) (Math.random() * (b - a) + a)));
		return tempo;
	}
	
	public static void mostraTempo(long tempo)
	{
		long segundos, minutos, horas;
		segundos = ( tempo / 1000 ) % 60;
		minutos  = ( tempo / 60000 ) % 60;
		horas    = tempo / 3600000; 
		
		System.out.print( ""+String.format( "%02d:%02d:%02d", horas, minutos,segundos )+"\n");
	}
	
}
