


/*
 * Pontificia Universidade Catolica de Minas Gerais
 * Ciencia da Computacao - 2016
 * Autor(a): Ana Carolina Conceicao de Jesus
 * 
 */

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;

public class DatabaseColetor implements TransacoesDatabaseColetor{

	private Conexao conexao;
	
	public DatabaseColetor(Conexao con)
	{
		setConexao(con);
	}
	
	/* atualizar o campo pais da url com id igual ao codigo recebido por parametro */
	public boolean updatePais(int codigo, String pais) {
        boolean update = false;
        try {
        	Statement stm = conexao.getConnection().createStatement();
        	ResultSet consulta = stm.executeQuery("SELECT pais from Pessoa where id = '"+codigo+"'");
		
			if(consulta.next())
			{
			  String paisrecuperado = consulta.getString("pais");
			  
			  if(paisrecuperado == null)
			  {
				  String sql = "update pessoa set pais = '"+pais+"' where id = "+codigo+";";
		          Connection c = conexao.getConnection();
		          PreparedStatement ps = c.prepareStatement(sql);
		          update  = ps.execute();
			  }
			  
			}
        
        } catch (SQLException e) {
            e.printStackTrace();
        }
      return update;
    }
	
	/* pegar os links que o campo pais esta null */
	public HashMap<String, String> pegarPaisesNull()
	{
		HashMap<String, String> paises_null = null;
		
		Connection c = conexao.getConnection();
		String sql = "SELECT *from Pessoa where pais is null";
		PreparedStatement ps;
		try {
			ps = c.prepareStatement(sql);
			ResultSet consulta = ps.executeQuery();	
			paises_null = new HashMap<String, String>();
			String nome;
			String id;
			try 
			{
				while(consulta.next())
				{
				  id = consulta.getString("id");
				  nome = consulta.getString("nome");
				  paises_null.put(id, nome);
				}
			} 
			catch (SQLException e) 
			{
				e.printStackTrace();
			}
			
		} 
		catch (SQLException e1) 
		{
			e1.printStackTrace();
		}
		
		return paises_null;
	}
	
	
	
	/* insere um link no banco de dados ok */
	public boolean inserirLink(String nome, String url) {
		boolean inserir = false;
		try {
			String sql = "INSERT INTO Pessoa VALUES (DEFAULT,'"+nome+"','"+url+"', DEFAULT, DEFAULT)";
			Connection c = conexao.getConnection();
			PreparedStatement ps = c.prepareStatement(sql);
			inserir = ps.execute();

		} catch (SQLException e) {
			e.printStackTrace();
		}
      return inserir;
	}

	/* retorna o codigo atribuido a pagina quando ela foi adicionada [usado para salvar o html] ok*/
	public String pegarIdLink(String url) {
		String nomArq = "";
		try {
			Statement stm = conexao.getConnection().createStatement();
			ResultSet consulta = stm.executeQuery("SELECT id, nome from Pessoa where url = '"+url+"'");
			
			if(consulta.next())
			{
			  String codigo = consulta.getString("id");
			  String nome = consulta.getString("nome");
			  nomArq = codigo +" - "+nome;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("Erro pegando ID no BD!!!");
			
		}
		
		return nomArq;
	}
	
	public String pegarMaquina(String url) {
		String ipmaquina = "";
		try {
			Statement stm = conexao.getConnection().createStatement();
			ResultSet consulta = stm.executeQuery("SELECT maquina from Pessoa where url = '"+url+"'");
			
			if(consulta.next())
			{
			  ipmaquina = consulta.getString("maquina");
			}
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("Erro pegando IP de maquina no BD!!!");
			
		}
		
		return ipmaquina;
	}

	
	

	/* atualiza o campo data da coleta ok */
	public boolean setDataColeta(String url, String data) {
		boolean atualizado = false;
		try 
		{
			String consultasql = "SELECT data_coleta from Pessoa where url = '"+url+"'";
			Connection c = conexao.getConnection();
			PreparedStatement ps = c.prepareStatement(consultasql);
			
			ResultSet resultado = ps.executeQuery();
			
			if(resultado.next())
			{
				resultado.getString("data_coleta");
				if(resultado.wasNull())
				{
					String atualizasql = "UPDATE Pessoa SET data_coleta = '"+data+"' where url = '"+url+"'";
					PreparedStatement sp = c.prepareStatement(atualizasql);
					atualizado = true;
					sp.execute();
					
				}
				
			}
			
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}		
	
		return atualizado;
	}

	/* atualiza o campo ip ok */
	public boolean setIP(String url, String ip) {
		boolean atualizado = false;
		try 
		{
			String consultasql = "SELECT maquina from Pessoa where url = '"+url+"'";
			Connection c = conexao.getConnection();
			PreparedStatement ps = c.prepareStatement(consultasql);
			
			ResultSet resultado = ps.executeQuery();
			
			if(resultado.next())
			{
				resultado.getString("maquina");
				if(resultado.wasNull())
				{
					String atualizasql = "UPDATE Pessoa SET maquina = '"+ip+"' where url = '"+url+"'";
					PreparedStatement sp = c.prepareStatement(atualizasql);
					atualizado = sp.execute();
					
				}
				
			}
			
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}		
	
		return atualizado;
	}

	/* consulta se o link esta no banco de dados */
	public boolean consultarLink(String url) {
		boolean teste = false;
		try 
		{
			Statement stm = conexao.getConnection().createStatement();
			ResultSet consulta = stm.executeQuery("SELECT id from pessoa where url = '"+url+"'");
			
			if(consulta.next())
			{
				teste = true;
			}
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
			System.out.println("Erro consultando no BD!!!");
		}
		
		return teste;
	}


	/* verifica se a data da coleta esta null ou nao */
	public boolean consultarCampoDataColeta(String url) {
		boolean teste = false;
		try 
		{
			Connection c = conexao.getConnection();
			String sql = "SELECT data_coleta from Pessoa where url = '"+url+"'";
			PreparedStatement ps =  c.prepareStatement(sql);
			ResultSet consulta = ps.executeQuery();
			
			if(consulta.next())
			{
				consulta.getString("data_coleta");
				if(consulta.wasNull())
				{
					teste = true;
				}
				else
				{
					teste = false;
				}
			}
			
		}
		catch (SQLException e) 
		{
			e.printStackTrace();
			System.out.println("Erro consultando no BD!!!");
		}
		
		return teste;
	}

	/* retorna um hashmap com todas as urls presentes no banco que ainda n�o foram baixadas */
	public HashMap<Integer, Semente> pegarSementes() {
		HashMap<Integer, Semente> hash = null;
		
		try {
			Connection c = conexao.getConnection();
			String sql = "SELECT *from Pessoa where data_coleta is null and maquina is null";
			PreparedStatement ps = c.prepareStatement(sql);
			ResultSet consulta = ps.executeQuery();			
			hash = new HashMap<Integer, Semente>();
			Semente link = null;
			
			Integer id;
			String nome;
			String url;
			while(consulta.next())
			{
			  id = Integer.parseInt(consulta.getString("id"));
			  nome = consulta.getString("nome");
			  url = consulta.getString("url");
			  
			  link = new Semente(nome, url);
			  hash.put(id, link);
			}
		
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("Erro recuperando sementes no BD!!!");
			
		}
		
		return hash;
	}
	
	public Conexao getConexao() {
		return conexao;
	}

	public void setConexao(Conexao conexao) {
		this.conexao = conexao;
	}

	public HashMap<Integer, Link> verificar_coletados() 
	{
		HashMap<Integer, Link> hash = null;
		
		try {
			Connection c = conexao.getConnection();
			String sql = "SELECT *from Pessoa where data_coleta is not null and maquina is not null";
			PreparedStatement ps = c.prepareStatement(sql);
			ResultSet consulta = ps.executeQuery();			
			hash = new HashMap<Integer, Link>();
			Semente link = null;
			
			Integer id;
			String nome;
			String url;
			while(consulta.next())
			{
			  id = Integer.parseInt(consulta.getString("id"));
			  nome = consulta.getString("nome");
			  url = consulta.getString("url");
			  
			  link = new Semente(nome, url);
			  hash.put(id, link);
			}
		
		} catch (SQLException e) {
			e.printStackTrace();
			
			
		}
		
		return hash;
	}

	public boolean corrigirData(String link) 
	{
		boolean corrigido = false;
		
		try 
		{
			String consultasql = "SELECT data_coleta from Pessoa where url = '"+link+"'";
			Connection c = conexao.getConnection();
			PreparedStatement ps = c.prepareStatement(consultasql);
			
			ResultSet resultado = ps.executeQuery();
			
			if(resultado.next())
			{
				resultado.getString("data_coleta");
				
				String atualizasql = "UPDATE Pessoa SET data_coleta = DEFAULT where url = '"+link+"'";
				PreparedStatement sp = c.prepareStatement(atualizasql);
				corrigido = sp.execute();
		
			}
		}
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
	
		
		
		return corrigido;
	}

	public boolean corrigirMaquina(String link) 
	{
		boolean corrigido = false;
		
		try 
		{
			String consultasql = "SELECT maquina from Pessoa where url = '"+link+"'";
			Connection c = conexao.getConnection();
			PreparedStatement ps = c.prepareStatement(consultasql);
			
			ResultSet resultado = ps.executeQuery();
			
			if(resultado.next())
			{
				resultado.getString("maquina");
				
				String atualizasql = "UPDATE Pessoa SET maquina = DEFAULT where url = '"+link+"'";
				PreparedStatement sp = c.prepareStatement(atualizasql);
				corrigido = sp.execute();
		
			}
		}
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
	
		return corrigido;
	}
	
	
	public boolean corrigirData(String link, String data) 
	{
		boolean corrigido = false;
		
		try 
		{
			String consultasql = "SELECT data_coleta from Pessoa where url = '"+link+"'";
			Connection c = conexao.getConnection();
			PreparedStatement ps = c.prepareStatement(consultasql);
			
			ResultSet resultado = ps.executeQuery();
			
			if(resultado.next())
			{
				resultado.getString("data_coleta");
				
				String atualizasql = "UPDATE Pessoa SET data_coleta = '"+data+"' where url = '"+link+"'";
				PreparedStatement sp = c.prepareStatement(atualizasql);
				corrigido = sp.execute();
		
			}
		}
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
	
		
		
		return corrigido;
	}

	public boolean corrigirMaquina(String link, String maquina) 
	{
		boolean corrigido = false;
		
		try 
		{
			String consultasql = "SELECT maquina from Pessoa where url = '"+link+"'";
			Connection c = conexao.getConnection();
			PreparedStatement ps = c.prepareStatement(consultasql);
			
			ResultSet resultado = ps.executeQuery();
			
			if(resultado.next())
			{
				resultado.getString("maquina");
				
				String atualizasql = "UPDATE Pessoa SET maquina = '"+maquina+"' where url = '"+link+"'";
				PreparedStatement sp = c.prepareStatement(atualizasql);
				corrigido = sp.execute();
		
			}
		}
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
	
		return corrigido;
	}
	

	public HashMap<Integer, Link> verificar_maquina_setada_e_data_null() {
		
		HashMap<Integer, Link> recuperados = null;
		
		try {
			Connection c = conexao.getConnection();
			String sql = "SELECT *from Pessoa where maquina is not null and data_coleta is null";
			PreparedStatement ps = c.prepareStatement(sql);
			ResultSet consulta = ps.executeQuery();			
			recuperados = new HashMap<Integer, Link>();
			Link link = null;
			
			Integer id;
			String nome;
			String url;
			while(consulta.next())
			{
			  id = Integer.parseInt(consulta.getString("id"));
			  nome = consulta.getString("nome");
			  url = consulta.getString("url");
			  
			  link = new Semente(nome, url);
			  recuperados.put(id, link);
			}
		
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
	
		return recuperados;
	}
	
	public HashMap<Integer, Link> verificar_nao_coletados() {
		
		HashMap<Integer, Link> recuperados = null;
		
		try {
			Connection c = conexao.getConnection();
			String sql = "SELECT *from Pessoa where maquina is null and data_coleta is null";
			PreparedStatement ps = c.prepareStatement(sql);
			ResultSet consulta = ps.executeQuery();			
			recuperados = new HashMap<Integer, Link>();
			Link link = null;
			
			Integer id;
			String nome;
			String url;
			while(consulta.next())
			{
			  id = Integer.parseInt(consulta.getString("id"));
			  nome = consulta.getString("nome");
			  url = consulta.getString("url");
			  
			  link = new Semente(nome, url);
			  recuperados.put(id, link);
			}
		
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
	
		return recuperados;
	}
	
	
	
}
