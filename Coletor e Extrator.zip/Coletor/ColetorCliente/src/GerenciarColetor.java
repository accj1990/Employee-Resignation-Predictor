import java.util.Timer;


public class GerenciarColetor implements Runnable{

	private Coletor c;
	private boolean diminuir;
	private boolean aumentar;
	private Timer time1, time2;
	private TarefaAtribuirIntervalo t1;
	private TarefaAumentarOuDiminuirIntervalo t2;

	public GerenciarColetor(Coletor c)
	{
		this.c = c;
		this.setDiminuir(false);
		this.setAumentar(false);
		this.time1 = new Timer();
		this.time2 = new Timer();
		this.t1 = new TarefaAtribuirIntervalo(c);
		this.t2 = new TarefaAumentarOuDiminuirIntervalo(c);
	}
	
	public void run() {
		time1.scheduleAtFixedRate(t1,0,18000000); // trocar para 18000000 = 5h
		time2.scheduleAtFixedRate(t2, 0, 900000);
	}

	public boolean isDiminuir()
	{
		return diminuir;
	}

	public void setDiminuir(boolean diminuir)
	{
		this.diminuir = diminuir;
	}

	public boolean isAumentar()
	{
		return aumentar;
	}

	public void setAumentar(boolean aumentar)
	{
		this.aumentar = aumentar;
	}
	
	public Coletor getColetor()
	{
		return this.c;
	}

}
