

import java.net.HttpURLConnection;
import java.net.URL;

public class VerificarSite {
	
  public static String verificarSite()
  {
	  String[] sites = {"http://www.meuenderecoip.com", "http://meuip.datahouse.com.br", 
		         "http://www.hlera.com.br/meu_ip/", "http://www.abusar.org.br",
		         "http://www.mostrarip.com.br"};
	  
	  String siteValido = "";
	  
	  for(int i = 0; i < sites.length; i++){
	    try 
	    {
		  URL url = new URL(sites[i]);
		  HttpURLConnection conexao = (HttpURLConnection) url.openConnection();
		  int codigo = conexao.getResponseCode();
		  if(codigo == 200)
		  {
		     siteValido = sites[i];
		  }
		} 
	    catch (Exception e) 
		{
	    	// site invalido
	    }
     }
	 return siteValido;
  }

}
