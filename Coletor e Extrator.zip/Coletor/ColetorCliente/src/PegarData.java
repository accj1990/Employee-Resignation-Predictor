

import java.text.SimpleDateFormat;
import java.util.Date;

public class PegarData {

	public static String pegarData()
	{
		//pegar data atual
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		String data = sdf.format(new Date( System.currentTimeMillis()));
		return data;
	}
	
}
