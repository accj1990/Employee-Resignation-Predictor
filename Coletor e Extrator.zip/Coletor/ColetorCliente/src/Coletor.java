
import java.io.IOException;
import java.net.Socket;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Queue;


public class Coletor implements Runnable{

	private HashMap<String,String> extraidos;
	private Queue<Link> fila;
	private Link semente;
	private int contador;
	private DatabaseColetor database;
	private Socket cliente;
	private Conexao c;
    private String ip, data, nomarq;
    private long a,b; // intervalo entre as coletas
    private boolean dormir;
    private boolean aumentar;
    
	public Coletor(Socket cliente, Link s) {
	  this.dormir = false;
	  this.a = 5000;
	  this.b = 75000;
	  this.setAumentar(false);
	  this.setContador(0);
	  this.ip = PegarIP.pegarIp();
	  this.data = PegarData.pegarData();
	  this.cliente = cliente;
	  this.c = new Conexao();
	  this.database = new DatabaseColetor(c);
	  this.setSemente(s);
	  fila = new LinkedList<Link>();
	  fila.add(new Link(s.getNome(),s.getLink()));
	  HashVisitados.iniciar();
	  baixarSemente(s);
	  
	}
	
	public void baixarSemente(Link s)
	{
		try
		  {
			nomarq = database.pegarIdLink(s.getLink());
			Downloader.baixarpage(nomarq, s.getLink());
			setContador(getContador() + 1);
			database.setDataColeta(s.getLink(), data);
			database.setIP(s.getLink(), ip);
			Arquivo arquivo = EnviarArquivoServidor.lerArquivo(Downloader.path+nomarq);
			EnviarArquivoServidor.enviarArquivoServidor(cliente, arquivo);
			
			
		  }
		  catch (Exception e)
		  {
			e.printStackTrace();
		  }
	}
	
	@Override
	public void run() {
	
		buscaEmLargura();
	}

	public void buscaEmLargura()
	{
		Link vertice;
		Arquivo arquivo;
		
		while(!fila.isEmpty())
		{
			vertice = fila.peek(); // pega o primeiro da fila
			if(vertice != null) // se ele e diferente de null
			{
				extraidos = Downloader.extrailinks(database.pegarIdLink(vertice.getLink())); // extrai os links
				
				if(extraidos != null)
				{
					// para cada link extraido
					for(String e: extraidos.keySet())
					{
						Link url = new Link(e,extraidos.get(e));
						
						if(!HashVisitados.contains(url.getLink()))
						{
							   boolean inserir = database.inserirLink(url.getNome(), url.getLink());
							   if(inserir)
							   {
								   try 
								   {
									   nomarq = database.pegarIdLink(url.getLink());
									   Downloader.baixarpage(nomarq, url.getLink());
									   contador++;
									   HashVisitados.inserir(url.getNome(), url.getLink());
									   database.setDataColeta(url.getLink(), data);
									   database.setIP(url.getLink(), ip);
									   fila.add(new Link(url.getNome(), url.getLink()));
									   arquivo = EnviarArquivoServidor.lerArquivo(Downloader.path+nomarq);
								   	   EnviarArquivoServidor.enviarArquivoServidor(cliente, arquivo);
								   	   aumentar = true;
								   	   dormirAleatoriamente();
								   } 
								   catch (Exception e1) 
							   	   {
							   		   e1.printStackTrace();
									
							   		   if (e1.getMessage().contains("999") || 
							   				   e1.getMessage().contains("Read timed out") || 
							   				   		e1.getMessage().contains("br.linkedin.com"))
							   		   {
							   			   salvarFilaBD(fila);
							   			   sair();
							   		   }
							   		   
									
							   	   }
							   }
							   else{
								    database.setIP(url.getLink(), ip);
								    try 
									   {
										   nomarq = database.pegarIdLink(url.getLink());
										   if(database.pegarMaquina(url.getLink()).equals(ip))
										   {
											   Downloader.baixarpage(nomarq, url.getLink());
											   database.setDataColeta(url.getLink(), data);
											   contador++;
											   fila.add(new Link(url.getNome(), url.getLink()));
											   arquivo = EnviarArquivoServidor.lerArquivo(Downloader.path+nomarq);
										   	   EnviarArquivoServidor.enviarArquivoServidor(cliente, arquivo);
										   	   aumentar = true;
										   }
										   HashVisitados.inserir(url.getNome(), url.getLink());
									   	   dormirAleatoriamente();
									   } 
									   catch (Exception e1) 
								   	   {
								   		   e1.printStackTrace();
										
								   		   if (e1.getMessage().contains("999") || 
								   				   e1.getMessage().contains("Read timed out") || 
								   				   		e1.getMessage().contains("br.linkedin.com"))
								   		   {
								   			   salvarFilaBD(fila);
								   			   sair();
								   		   }
								   		   
										
								   	   }
							   }
							
				
						}
						else if (fila.contains(new Link(url.getNome(),url.getLink())))
						{
							   boolean inserir = database.inserirLink(url.getNome(), url.getLink());
							   if(inserir)
							   {
								   	try 
								   	{
								   		nomarq = database.pegarIdLink(url.getLink());
								   		Downloader.baixarpage(nomarq, url.getLink());
								   		contador++;
								   		database.setDataColeta(url.getLink(), data);
								   		database.setIP(url.getLink(), ip);
								   		arquivo = EnviarArquivoServidor.lerArquivo(Downloader.path+nomarq);
								   		EnviarArquivoServidor.enviarArquivoServidor(cliente, arquivo);
								   		aumentar = false;
								   		dormirAleatoriamente();
								   	}
								    catch (Exception e1) 
								   	{
								    	e1.printStackTrace();
								   		if (e1.getMessage().contains("999") || 
								   				e1.getMessage().contains("Read timed out") || 
								   					e1.getMessage().contains("br.linkedin.com"))
								   		{
								   			   
								   			salvarFilaBD(fila);
								   			sair();
								   			
								   		}
								   		   
										
								   	}
							   }
							   else{
								    database.setIP(url.getLink(), ip);
								 	try 
								   	{
								   		nomarq = database.pegarIdLink(url.getLink());
								   		if(database.pegarMaquina(url.getLink()).equals(ip))
								   		{
								   			Downloader.baixarpage(nomarq, url.getLink());
								   			contador++;
								   			database.setDataColeta(url.getLink(), data);
								   			arquivo = EnviarArquivoServidor.lerArquivo(Downloader.path+nomarq);
								   			EnviarArquivoServidor.enviarArquivoServidor(cliente, arquivo);
								   			aumentar = false;
								   			dormirAleatoriamente();
								   		}
								   		
								   	}
								    catch (Exception e1) 
								   	{
								    	e1.printStackTrace();
								   		if (e1.getMessage().contains("999") || 
								   				e1.getMessage().contains("Read timed out") || 
								   					e1.getMessage().contains("br.linkedin.com"))
								   		{
								   			   
								   			salvarFilaBD(fila);
								   			sair();
								   			
								   		}
								   		   
										
								   	}
							   }
						}	
					}	
				}
			}
			fila.remove(vertice);
			System.out.println(" ####### CONTADOR : "+contador+ " #######");
		}
		
	}
	
	private void dormirAleatoriamente() 
	{
		try 
		{
			long tempo = GerarTempoAleatorio.gerarTempo(a, b);
			System.out.println( " ####### Dormir #########");
			GerarTempoAleatorio.mostraTempo(tempo);
			Thread.sleep(tempo);
			
		} catch (InterruptedException e) {
			System.out.println(" Erro dormirAleatoriamente()");
			e.printStackTrace();
		}
		
	}
	
	private void sair()
	{
		System.out.println(" ### Encerrando execu��o ### ");
		System.exit(0);
		try {
			cliente.close();
		} catch (IOException e) {
		
			e.printStackTrace();
		}
		
	}
	
	/* mexer nesse codigo pra ajustar se nao conseguir baixar blabla */
	public void salvarFilaBD(Queue<Link> link)
	{
		System.out.println(" ####### Salvando fila de Downloads ... ####### ");
		System.out.println(" ####### Tamanho da fila :"+link.size()+" ######## ");
		Iterator<Link> i = link.iterator();
		int cont=0;
		boolean inserir;
		while (i.hasNext()) {
		   Link url = i.next();
		   if (!database.consultarLink(url.getLink()))
		   {
			   inserir = database.inserirLink(url.getNome(), url.getLink());
		   	   if(inserir){cont++;}
		   }
		}
		System.out.println(" ####### Links inseridos no Banco :"+cont+" ######## ");
		System.out.println(" ####### Finalizado ####### ");
	}
	
	public Queue<Link> getFila() {
		return fila;
	}


	public void setFila(Queue<Link> fila) {
		this.fila = fila;
	}
	
	public HashMap<String,String> getExtraidos() {
		return extraidos;
	}


	public void setExtraidos(HashMap<String,String> extraidos) {
		this.extraidos = extraidos;
	}

	public Link getSemente() {
		return semente;
	}

	public void setSemente(Link semente) {
		this.semente = semente;
	}

	public int getContador() {
		return contador;
	}

	public void setContador(int contador) {
		this.contador = contador;
	}

	public boolean isDormir() {
		return dormir;
	}

	public void setDormir(boolean dormir) {
		this.dormir = dormir;
	}
	
	public long getA()
	{
		return this.a;
	}
	
	public void setA(long a)
	{
		this.a = a;
	}
	
	public long getB()
	{
		return this.b;
	}
	
	public void setB(long b)
	{
		this.b = b;
	}
	
	public boolean isAumentar() {
		return aumentar;
	}

	public void setAumentar(boolean aumentar) {
		this.aumentar = aumentar;
	}

	

}
