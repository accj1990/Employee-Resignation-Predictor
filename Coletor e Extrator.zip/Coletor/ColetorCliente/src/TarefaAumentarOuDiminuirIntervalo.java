import java.util.TimerTask;


public class TarefaAumentarOuDiminuirIntervalo extends TimerTask{

	private Coletor c;
	public TarefaAumentarOuDiminuirIntervalo(Coletor c)
	{
		this.c = c;
	}
	public void run() {
		if(!c.isDormir())
		{
			if (c.isAumentar())
			{
				System.out.println(" ### Aumentando intervalo de coleta ... ### ");
				aumentarIntervalo();
			}
			else
			{
				System.out.println(" ### Diminuido intervalo de coleta ... ### ");
				diminuirIntervalo();
			}
		}
		
	}
	
	public void aumentarIntervalo()
	{
		long a = GerarTempoAleatorio.gerarTempo(5000,90000);
		long b = GerarTempoAleatorio.gerarTempo(5000,90000);
		
		c.setA(c.getA()+a);
		c.setB(c.getB()+b);
	}
	
	public void diminuirIntervalo()
	{
		long a = GerarTempoAleatorio.gerarTempo(5000,90000);
		
		while(a <= c.getA())
		{
			a = GerarTempoAleatorio.gerarTempo(5000,90000);
		}
		
		long b = GerarTempoAleatorio.gerarTempo(5000,90000);
		
		while(b <= c.getB())
		{
			b = GerarTempoAleatorio.gerarTempo(5000,90000);
		}
	
		c.setA(c.getA() - a);
		c.setB(c.getB() - b);
	}

}
