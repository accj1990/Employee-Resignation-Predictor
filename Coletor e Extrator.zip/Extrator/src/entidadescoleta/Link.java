package entidadescoleta;


import java.io.Serializable;

@SuppressWarnings("serial")
public class Link implements Serializable {
	
	private String nome;
	private String link;
	private Integer id = -1;
	 
	public Link(String nome, String link)
	{
		this.nome = nome;
		this.link = link;
	}
	 
	public String getNome() {
		return this.nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getLink() {
		return this.link;
	}
	public void setLink(String link) {
		this.link = link;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}
}
