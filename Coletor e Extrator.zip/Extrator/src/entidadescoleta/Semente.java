package entidadescoleta;

@SuppressWarnings("serial")
public class Semente extends Link{

	public Semente(String nome, String link) {
		super(nome, link);
	}
}
