package testeaceitacao;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

public class Main {

	static HashMap<String, ArrayList<String>> hash_cargos;
	static ArrayList<String> cargos_des;
	public static void main(String[] args) 
	{
		 //Conexao c1 = new Conexao("Coletor");
		//Conexao c2 = new Conexao("TCC");
		
		//DatabaseProfissionais base1 = new DatabaseProfissionais(c1);
		//base1.getCargos();
		
		// DatabaseCargosPadronizados base2 = new  DatabaseCargosPadronizados(c2);
		// base2.getCargos();
		
		hash_cargos = new HashMap<String, ArrayList<String>>();
		cargos_des = new ArrayList<String>();
		String vet [] = {"a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","x","w","y","z"};
		
		for(String e: vet)
		{
			hash_cargos.put(e, new ArrayList<String>());
		}
		
		lerArquivoCargosPadronizados();
		lerArquivoCargosDesPadronizados();
		comparar();
		
	}
	
	public static void lerArquivoCargosPadronizados()
	{
		try 
		{
			Scanner in = new Scanner (new File("C:\\Users\\Carol\\Desktop\\cargos_padronizados.txt"));
			while(in.hasNext())
			{	
				in.nextInt();
				String cargo = in.nextLine().trim();
				hash_cargos.get(""+cargo.charAt(0)).add(cargo);
			}
		} 
		catch (FileNotFoundException e) 
		{
			e.printStackTrace();
		}
	}
	
	public static void lerArquivoCargosDesPadronizados()
	{
		try 
		{
			//Scanner in = new Scanner (new File("C:\\Users\\Carol\\Desktop\\cargos_prof.txt"));
			Scanner in = new Scanner (new File("C:\\Users\\Carol\\Desktop\\cargosTI.txt"));
			while(in.hasNext())
			{	
				in.nextInt();
				String cargo = in.nextLine().trim();
				cargos_des.add(cargo);
			}
		} 
		catch (FileNotFoundException e) 
		{
			e.printStackTrace();
		}
	}
	
	public static void comparar()
	{
		int contador_rejeitados = 0;
		int contador_aceitos = 0;
		int contador = 1;
		for (int i = 0; i < cargos_des.size(); i++)
		{
			String cargo_despadronizado = cargos_des.get(i);
			System.out.println("CARGO DESPADRONIZADO: "+cargo_despadronizado);
			ArrayList <String> opcoes_cargo = hash_cargos.get(""+cargo_despadronizado.charAt(0));
			String cargo;
			boolean flag = false;
			for (int j = 0; j < opcoes_cargo.size(); j++)
			{
				cargo = opcoes_cargo.get(j);
				if (cargo_despadronizado.contains(cargo))
				{
					System.out.println(contador+ " Aceito: "+cargo_despadronizado+" = "+cargo);
					contador_aceitos++;
					flag = true;
					break;
				}
			}
			
			if (flag == false)
			{
				System.out.println(contador+" Rejeitado: "+cargo_despadronizado+" NAO FOI ENCONTRADO");
				contador_rejeitados++;
			}
			
			contador++;
		}
		
		
		System.out.println("Aceitos: "+contador_aceitos);
		System.out.println("Rejeitados: "+contador_rejeitados);

		
	}

}
