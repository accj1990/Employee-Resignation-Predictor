package testeaceitacao;

public class Profissional 
{
	private int id_prof;
	private String nome_prof;
	private String cargo;
	private int id_area;
	private int id_localidade;
	private int total_formacao;
	private int tempo_formacao;
	private int atual;
	private int anterior;
	private int total_idiomas;
	private int total_competencias;
	private int total_conexoes;
	private int total_experiencias;
	private double porcentagem_media;
	private double porcentagem_moda;
	private double porcentagem_mediana;
	
	public Profissional(int id_prof, String nome_prof, String cargo,int id_area,
							int id_localidade, int total_formacao,int tempo_formacao, int atual, 
								int anterior, int total_idiomas, int total_competencias,
									int total_conexoes, int total_experiencias, double porcentagem_media, 
										double porcentagem_moda, double porcentagem_mediana)
	{
		this.id_prof = id_prof;
		this.nome_prof = nome_prof;
		this.cargo = cargo;
		this.id_area = id_area;
		this.id_localidade = id_localidade;
		this.total_formacao = 
		this.tempo_formacao = tempo_formacao;
		this.atual = atual;
		this.anterior = anterior;
		this.total_idiomas = total_idiomas;
		this.total_competencias = total_competencias;
		this.total_conexoes = total_conexoes;
		this.total_experiencias = total_experiencias;
		this.porcentagem_media = porcentagem_media;
		this.porcentagem_moda = porcentagem_moda;
		this.porcentagem_mediana = porcentagem_mediana;
	}
	
	public int getId() 
	{
		return id_prof;
	}
	public void setId(int id_prof) 
	{
		this.id_prof = id_prof;
	}
	
	public String getNome() 
	{
		return nome_prof;
	}
	public void setNome(String nome_prof) 
	{
		this.nome_prof = nome_prof;
	}

	public int getId_area() 
	{
		return id_area;
	}
	public void setId_area(int id_area) 
	{
		this.id_area = id_area;
	}

	public int getId_localidade() 
	{
		return id_localidade;
	}
	public void setId_localidade(int id_localidade) 
	{
		this.id_localidade = id_localidade;
	}

	public int getTempo_formacao() 
	{
		return tempo_formacao;
	}
	public void setTempo_formacao(int tempo_formacao) 
	{
		this.tempo_formacao = tempo_formacao;
	}

	public int getAtual() 
	{
		return atual;
	}
	public void setAtual(int atual) 
	{
		this.atual = atual;
	}

	public int getAnterior() 
	{
		return anterior;
	}
	public void setAnterior(int anterior) 
	{
		this.anterior = anterior;
	}

	public int getTotal_idiomas() 
	{
		return total_idiomas;
	}
	public void setTotal_idiomas(int total_idiomas)
	{
		this.total_idiomas = total_idiomas;
	}

	public int getTotal_competencias() 
	{
		return total_competencias;
	}
	public void setTotal_competencias(int total_competencias) 
	{
		this.total_competencias = total_competencias;
	}

	public int getTotal_conexoes() 
	{
		return total_conexoes;
	}
	public void setTotal_conexoes(int total_conexoes) 
	{
		this.total_conexoes = total_conexoes;
	}

	public int getTotal_experiencias() 
	{
		return total_experiencias;
	}
	public void setTotal_experiencias(int total_experiencias) 
	{
		this.total_experiencias = total_experiencias;
	}

	public int getTotal_formacao() {
		return total_formacao;
	}

	public void setTotal_formacao(int total_formacao) {
		this.total_formacao = total_formacao;
	}

	public String getCargo() {
		return cargo;
	}

	public void setCargo(String cargo) {
		this.cargo = cargo;
	}

	public double getPorcentagem_media() {
		return porcentagem_media;
	}

	public void setPorcentagem_media(double porcentagem_media) {
		this.porcentagem_media = porcentagem_media;
	}

	public double getPorcentagem_moda() {
		return porcentagem_moda;
	}

	public void setPorcentagem_moda(double porcentagem_moda) {
		this.porcentagem_moda = porcentagem_moda;
	}

	public double getPorcentagem_mediana() {
		return porcentagem_mediana;
	}

	public void setPorcentagem_mediana(double porcentagem_mediana) {
		this.porcentagem_mediana = porcentagem_mediana;
	}

}
