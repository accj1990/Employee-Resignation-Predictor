package testeaceitacao;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class DatabaseCargosPadronizados 
{
	private Conexao conexao;
	
	public DatabaseCargosPadronizados (Conexao con)
	{
		setConexao(con);
	}
	
	public void setConexao(Conexao conexao) 
	{
		this.conexao = conexao;
	}
	
	
	public void getCargos()
	{
		try 
		{
			FileWriter arq;
			try {
				arq = new FileWriter("C:\\Users\\Carol\\Desktop\\cargos_padronizados.txt");
				PrintWriter gravarArq = new PrintWriter(arq);
				int i = 1;
				Statement stm = conexao.getConnection().createStatement();
				ResultSet consulta = stm.executeQuery("select nome_cargo from cargo;");
				
				while(consulta.next())
				{
				  String cargo = consulta.getString("nome_cargo");
				  gravarArq.println(i+" "+cargo);
				  i++;
				}
				
				gravarArq.close();
			} catch (IOException e) {
				e.printStackTrace();
			}

		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}

	}
	
}
