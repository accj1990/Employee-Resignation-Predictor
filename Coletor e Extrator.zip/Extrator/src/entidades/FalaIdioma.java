package entidades;

public class FalaIdioma 
{
	private int id_prof;
	private int id_idioma;
	
	public FalaIdioma(int id_prof, int id_idioma)
	{
		this.id_prof = id_prof;
		this.id_idioma = id_idioma;
	}

	public int getId_prof() 
	{
		return id_prof;
	}

	public void setId_prof(int id_prof) 
	{
		this.id_prof = id_prof;
	}

	public int getId_idioma() 
	{
		return id_idioma;
	}

	public void setId_idioma(int id_idioma)
	{
		this.id_idioma = id_idioma;
	}

}
