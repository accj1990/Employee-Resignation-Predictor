package entidades;

public class Grau_Formacao 
{
	private int id_grau;
	private String nome_grau;
	
	
	public Grau_Formacao(int id_grau, String nome_grau)
	{
		this.setId_grau(id_grau);
		this.setNome_grau(nome_grau);
	}


	public int getId_grau() {
		return id_grau;
	}


	public void setId_grau(int id_grau) {
		this.id_grau = id_grau;
	}


	public String getNome_grau() {
		return nome_grau;
	}


	public void setNome_grau(String nome_grau) {
		this.nome_grau = nome_grau;
	}
	
	
	
}
