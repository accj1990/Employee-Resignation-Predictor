package entidades;

public class Area 
{
	private int id_area;
	private String nome_area;
	private int rotatividade_media;
	private int rotatividade_moda;
	private int rotatividade_mediana;
	
	public Area(int id_area, String nome_area, int rotatividade_media,
			 int rotatividade_moda, int rotatividade_mediana)
	{
		this.id_area = id_area;
		this.nome_area = nome_area;
		this.rotatividade_media = rotatividade_media;
		this.rotatividade_moda = rotatividade_moda;
		this.rotatividade_mediana = rotatividade_mediana;
	}
	
	public int getId_area() 
	{
		return id_area;
	}
	public void setId_area(int id_area) 
	{
		this.id_area = id_area;
	}
	public String getNome_area() 
	{
		return nome_area;
	}
	public void setNome_area(String nome_area) {
		this.nome_area = nome_area;
	}

	public int getRotatividade_media() {
		return rotatividade_media;
	}

	public void setRotatividade_media(int rotatividade_media) {
		this.rotatividade_media = rotatividade_media;
	}

	public int getRotatividade_mediana() {
		return rotatividade_mediana;
	}

	public void setRotatividade_mediana(int rotatividade_mediana) {
		this.rotatividade_mediana = rotatividade_mediana;
	}

	public int getRotatividade_moda() {
		return rotatividade_moda;
	}

	public void setRotatividade_moda(int rotatividade_moda) {
		this.rotatividade_moda = rotatividade_moda;
	}
	
}
