package entidades;

public class Localidade
{
	private int id_localidade;
	private int id_cidade;
	private int id_estado;
	
	public Localidade(int id_localidade, 
						int id_cidade, 
							int id_estado)
	{
		this.setId_localidade(id_localidade);
		this.setId_cidade(id_cidade);
		this.setId_estado(id_estado);
	}

	public int getId_localidade() 
	{
		return id_localidade;
	}

	public void setId_localidade(int id_localidade) 
	{
		this.id_localidade = id_localidade;
	}

	public int getId_cidade() 
	{
		return id_cidade;
	}

	public void setId_cidade(int id_cidade) 
	{
		this.id_cidade = id_cidade;
	}

	public int getId_estado() 
	{
		return id_estado;
	}

	public void setId_estado(int id_estado) 
	{
		this.id_estado = id_estado;
	}
	
}
