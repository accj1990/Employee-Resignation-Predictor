package entidades;

public class Formacao 
{
	private int id_instituicao;
	private int id_prof;
	private int id_grau;
	private int tempo_formacao;
	
	public Formacao(int id_instituicao, int id_prof, int id_grau,
			int tempo_formacao)
	{
		this.id_instituicao = id_instituicao;
		this.id_prof = id_prof;
		this.id_grau = id_grau;
		this.tempo_formacao = tempo_formacao;
	}

	public int getId_instituicao() 
	{
		return id_instituicao;
	}

	public void setId_instituicao(int id_instituicao) 
	{
		this.id_instituicao = id_instituicao;
	}

	public int getId_prof() 
	{
		return id_prof;
	}

	public void setId_prof(int id_prof) 
	{
		this.id_prof = id_prof;
	}

	public int getTempo_formacao() 
	{
		return tempo_formacao;
	}

	public void setTempo_formacao(int tempo_formacao) 
	{
		this.tempo_formacao = tempo_formacao;
	}

	public int getId_grau() {
		return id_grau;
	}

	public void setId_grau(int id_grau) {
		this.id_grau = id_grau;
	}
	
	
	
	
	
	
	
	
}
