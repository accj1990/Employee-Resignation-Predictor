package entidades;

public class Idioma 
{
	private int id_idioma;
	private String nome_idioma;
	
	public Idioma(int id_idioma, String nome_idioma)
	{
		this.id_idioma = id_idioma;
		this.nome_idioma = nome_idioma;
	}

	public int getId_idioma() 
	{
		return id_idioma;
	}

	public void setId_idioma(int id_idioma) 
	{
		this.id_idioma = id_idioma;
	}

	public String getNome_idioma() 
	{
		return nome_idioma;
	}

	public void setNome_idioma(String nome_idioma) 
	{
		this.nome_idioma = nome_idioma;
	}
	

}
