package entidades;

public class Instituicao 
{
	private int id_instituicao;
	private String nome_instituicao;
	
	public Instituicao(int id_instituicao, 
			String nome_instituicao)
	{
		this.id_instituicao = id_instituicao;
		this.nome_instituicao = nome_instituicao;
	}

	public int getId_instituicao() 
	{
		return id_instituicao;
	}

	public void setId_instituicao(int id_instituicao) 
	{
		this.id_instituicao = id_instituicao;
	}

	public String getNome_instituicao() 
	{
		return nome_instituicao;
	}

	public void setNome_instituicao(String nome_instituicao)
	{
		this.nome_instituicao = nome_instituicao;
	}
}
