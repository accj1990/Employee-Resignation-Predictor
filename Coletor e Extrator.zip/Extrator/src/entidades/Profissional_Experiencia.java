package entidades;

public class Profissional_Experiencia 
{

	private int id_exp;
	private int id_prof;
	private int tempo_trabalhado;
	
	
	public Profissional_Experiencia(int id_experiencia, 
			int id_prof, int tempo_trabalhado )
	{
		this.id_exp = id_experiencia;
		this.id_prof = id_prof;
		this.tempo_trabalhado = tempo_trabalhado;
	}
	public int getId_exp() {
		return id_exp;
	}

	public void setId_exp(int id_exp) {
		this.id_exp = id_exp;
	}
	
	public int getId_prof() 
	{
		return id_prof;
	}
	public void setId_prof(int id_prof) 
	{
		this.id_prof = id_prof;
	}
	public int getTempo_trabalhado() 
	{
		return tempo_trabalhado;
	}
	public void setTempo_trabalhado(int tempo_trabalhado) 
	{
		this.tempo_trabalhado = tempo_trabalhado;
	}

}
