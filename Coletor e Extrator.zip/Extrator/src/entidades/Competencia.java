package entidades;

public class Competencia 
{
	private int id_competencia;
	private String nome_competencia;
	
	public Competencia(int id_competencia, String nome_competencia)
	{
		this.id_competencia = id_competencia;
		this.nome_competencia = nome_competencia;
	}

	public int getId_compentencia() 
	{
		return id_competencia;
	}

	public void setId_compentencia(int id_competencia) 
	{
		this.id_competencia = id_competencia;
	}

	public String getNome_competencia() 
	{
		return nome_competencia;
	}

	public void setNome_competencia(String nome_competencia) 
	{
		this.nome_competencia = nome_competencia;
	}
}
