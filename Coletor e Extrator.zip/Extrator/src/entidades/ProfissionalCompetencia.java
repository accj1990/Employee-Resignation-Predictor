package entidades;

public class ProfissionalCompetencia 
{
	private int id_prof;
	private int id_competencia;
	
	public ProfissionalCompetencia (int id_prof, int id_competencia)
	{
		this.id_prof = id_prof;
		this.id_competencia = id_competencia;
	}

	public int getId_prof() 
	{
		return id_prof;
	}

	public void setId_prof(int id_prof) 
	{
		this.id_prof = id_prof;
	}

	public int getId_competencia() 
	{
		return id_competencia;
	}

	public void setId_idioma(int id_compentencia)
	{
		this.id_competencia = id_compentencia;
	}

}
