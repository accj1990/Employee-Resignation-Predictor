package entidades;

public class Experiencia 
{
	private int id_experiencia;
	private String nome_experiencia;

	
	
	public Experiencia(int id_experiencia, String nome_experiencia)
	{
		this.id_experiencia = id_experiencia;
		this.nome_experiencia = nome_experiencia;
	}
	
	public int getId_experiencia() 
	{
		return id_experiencia;
	}
	public void setId_experiencia(int id_experiencia) 
	{
		this.id_experiencia = id_experiencia;
	}
	public String getNome_experiencia() 
	{
		return nome_experiencia;
	}
	public void setNome_experiencia(String nome_experiencia) 
	{
		this.nome_experiencia = nome_experiencia;
	}
}
