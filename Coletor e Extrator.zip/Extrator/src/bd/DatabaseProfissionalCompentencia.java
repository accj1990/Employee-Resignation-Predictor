package bd;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import conexao.Conexao;
import entidades.ProfissionalCompetencia;

public class DatabaseProfissionalCompentencia
{
	private Conexao conexao;
	
	public DatabaseProfissionalCompentencia(Conexao con)
	{
		setConexao(con);
	}
	
	public Conexao getConexao() 
	{
		return conexao;
	}

	public void setConexao(Conexao conexao) 
	{
		this.conexao = conexao;
	}
	
	public boolean inserirProfissionalCompetencia(
			ProfissionalCompetencia profissional_compentencia) 
	{
		boolean inserir = false;
		try 
		{
			String sql = "INSERT INTO profissional_competencia VALUES ('"+profissional_compentencia.getId_competencia()+"','"+
					profissional_compentencia.getId_prof()+"')";		
			Connection c = conexao.getConnection();
			PreparedStatement ps = c.prepareStatement(sql);
			ps.execute();
			inserir = true;

		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
			
		return inserir;
	}

}
