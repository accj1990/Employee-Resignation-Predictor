package bd;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import conexao.Conexao;
import entidades.Grau_Formacao;

public class DatabaseGrauFormacao 
{

private Conexao conexao;
	
	public DatabaseGrauFormacao(Conexao con)
	{
		setConexao(con);
	}
	
	public Conexao getConexao() 
	{
		return conexao;
	}

	public void setConexao(Conexao conexao) 
	{
		this.conexao = conexao;
	}

	public boolean inserirGrauFormacao(Grau_Formacao grau) 
	{
		boolean inserir = false;
		try 
		{
			String sql = "INSERT INTO Grau_Formacao (id_grau, nome_grau) VALUES ("+grau.getId_grau()+",'"+grau.getNome_grau()+"')";		
			Connection c = conexao.getConnection();
			PreparedStatement ps = c.prepareStatement(sql);
			ps.execute();
			inserir = true;

		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		return inserir;
	}
	
	public int pegarIdGrau(String nome_grau) {
		int id_grau = -1;
		try {
			Statement stm = conexao.getConnection().createStatement();
			ResultSet consulta = stm.executeQuery("SELECT id_grau from Grau_Formacao where nome_grau = '"+nome_grau+"'");
			
			if(consulta.next())
			{
			  id_grau = consulta.getInt("id_grau");
			}
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("Erro pegando ID_Grau no BD!!!");
			
		}
		
		return id_grau;
	}
	
	
	
	
}
