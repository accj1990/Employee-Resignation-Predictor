package bd;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import conexao.Conexao;
import entidades.Localidade;

public class DatabaseLocalidade 
{
	private Conexao conexao;
	
	public DatabaseLocalidade(Conexao con)
	{
		setConexao(con);
	}
	
	public Conexao getConexao() 
	{
		return conexao;
	}

	public void setConexao(Conexao conexao) 
	{
		this.conexao = conexao;
	}
	
	public boolean inserirLocalidade(Localidade loc)
	{
		boolean inserir = false;
		try 
		{
			String sql = "INSERT INTO Localidade (id_localidade, id_cidade, id_estado) "
					+ "VALUES ("+loc.getId_cidade()+",'"+loc.getId_cidade()+ "','"+loc.getId_estado()+"')";		
			Connection c = conexao.getConnection();
			PreparedStatement ps = c.prepareStatement(sql);
			ps.execute();
			inserir = true;

		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		
		return inserir;
		
	}
	public int pegarIdLocalidade(Localidade loc) {
		int id_area = -1;
		try 
		{
			Statement stm = conexao.getConnection().createStatement();
			ResultSet consulta = stm.executeQuery("SELECT id_localidade from Localidade where id_cidade = '"+loc.getId_cidade()+"' and id_estado = '"+loc.getId_estado() +"'");
			
			if(consulta.next())
			{
			  id_area = consulta.getInt("id_localidade");
			}
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
			System.out.println("Erro pegando ID_Localidade no BD!!!");
			
		}
		
		return id_area;
	}
}
