package bd;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;

import entidades.Profissional;
import conexao.Conexao;

public class DatabaseProfissionais
{

	private Conexao conexao;
	
	public DatabaseProfissionais(Conexao con)
	{
		setConexao(con);
	}
	
	public Conexao getConexao() 
	{
		return conexao;
	}

	public void setConexao(Conexao conexao) 
	{
		this.conexao = conexao;
	}
	
	public boolean inserirProfissional(Profissional p) {
		boolean inserir = false;
		try 
		{
			String sql = "INSERT INTO Profissional VALUES ('"+p.getId()+"','"+p.getNome()+"','"+p.getCargo()+"','"+p.getId_area()+
					"','"+p.getId_cidade()+"','"+p.getId_estado()+"','"+p.getTotal_formacao()+"','"+p.getTempo_formacao()+"','"+p.getAtual()+"','"+
					p.getAnterior()+"','"+p.getTotal_idiomas()+"','"+p.getTotal_competencias()+"','"+
					p.getTotal_conexoes()+"','"+p.getTotal_experiencias()+"','"+p.getPorcentagem_media()+"','"+p.getPorcentagem_mediana()+"','"+p.getPorcentagem_moda()+"')";
					
			Connection c = conexao.getConnection();
			PreparedStatement ps = c.prepareStatement(sql);
			ps.execute();
			inserir = true;

		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
      return inserir;
	}

	
	public boolean updateTempoFormacao(Profissional p, int tempo_formacao) {
		 boolean update = false;
	        try {
	        	
			  String sql = "update profissional set total_tempo_formacao = '"+tempo_formacao+"' where id_prof = "+p.getId()+";";
			  Connection c = conexao.getConnection();
			  PreparedStatement ps = c.prepareStatement(sql);
			  update  = ps.execute();

	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	      return update;
	}

	public boolean updateTotalIdiomas(Profissional p, int total_idiomas) {
		boolean update = false;
	    try 
	    {
	    	String sql = "update profissional set total_idiomas = '"+total_idiomas+"' where id_prof = "+p.getId()+";";
			Connection c = conexao.getConnection();
			PreparedStatement ps = c.prepareStatement(sql);
			update  = ps.execute();

	    } 
	    catch (SQLException e) 
	    {
	        e.printStackTrace();
	    }
	      return update;
	}


	public boolean updateTotalCompetencias(Profissional p,
			int total_competencias) {
		boolean update = false;
	    try 
	    {
	    	String sql = "update profissional set total_competencias = '"+total_competencias+"' where id_prof = "+p.getId()+";";
			Connection c = conexao.getConnection();
			PreparedStatement ps = c.prepareStatement(sql);
			update  = ps.execute();

	    } 
	    catch (SQLException e) 
	    {
	        e.printStackTrace();
	    }
	      return update;
	}


	public boolean updateTotalConexoes(Profissional p, int total_conexoes) {
		boolean update = false;
	    try 
	    {
	    	String sql = "update profissional set total_conexoes = '"+total_conexoes+"' where id_prof= "+p.getId()+";";
			Connection c = conexao.getConnection();
			PreparedStatement ps = c.prepareStatement(sql);
			update  = ps.execute();

	    } 
	    catch (SQLException e) 
	    {
	        e.printStackTrace();
	    }
	      return update;
	}


	public boolean updateTotalExperiencias(Profissional p,
			int total_experiencias) {
		boolean update = false;
	    try 
	    {
	    	String sql = "update profissional set total_experiencias = '"+total_experiencias+"' where id_prof = "+p.getId()+";";
			Connection c = conexao.getConnection();
			PreparedStatement ps = c.prepareStatement(sql);
			update  = ps.execute();

	    } 
	    catch (SQLException e) 
	    {
	        e.printStackTrace();
	    }
	      return update;
	}

	public boolean updatePorcentagem(Profissional p, double porcentagem) {
		boolean update = false;
	    try 
	    {
	    	String sql = "update profissional set porcentagem = '"+porcentagem+"' where id = "+p.getId()+";";
			Connection c = conexao.getConnection();
			PreparedStatement ps = c.prepareStatement(sql);
			update  = ps.execute();

	    } 
	    catch (SQLException e) 
	    {
	        e.printStackTrace();
	    }
	      return update;
	}

	public boolean updateTotalFormacao(Profissional p, int total_formacao) {
		boolean update = false;
	    try 
	    {
	    	String sql = "update profissional set total_formacao = '"+total_formacao+"' where id_prof = "+p.getId()+";";
			Connection c = conexao.getConnection();
			PreparedStatement ps = c.prepareStatement(sql);
			update  = ps.execute();

	    } 
	    catch (SQLException e) 
	    {
	        e.printStackTrace();
	    }
	      return update;
	}
	
	public boolean updateCargo(Profissional p, String cargo) {
		boolean update = false;
	    try 
	    {
	    	String sql = "update profissional set cargo = '"+cargo+"' where id_prof = "+p.getId()+";";
			Connection c = conexao.getConnection();
			PreparedStatement ps = c.prepareStatement(sql);
			update  = ps.execute();

	    } 
	    catch (SQLException e) 
	    {
	        e.printStackTrace();
	    }
	      return update;
	}
	
	public boolean updatePorcentagemDaRotatividadeMedia(Integer id_prof, double porcentagem_rotatividade_media) {
		boolean update = false;
	    try 
	    {
	    	String sql = "update profissional set porcentagem_media = '"+porcentagem_rotatividade_media+"' where id_prof = "+id_prof+";";
			Connection c = conexao.getConnection();
			PreparedStatement ps = c.prepareStatement(sql);
			update  = ps.execute();

	    } 
	    catch (SQLException e) 
	    {
	        e.printStackTrace();
	    }
	      return update;
	}
	
	public boolean updatePorcentagemDaRotatividadeMediana(int id_prof, double porcentagem_rotatividade_mediana) {
		boolean update = false;
	    try 
	    {
	    	String sql = "update profissional set porcentagem_mediana = '"+porcentagem_rotatividade_mediana+"' where id_prof = "+id_prof+";";
			Connection c = conexao.getConnection();
			PreparedStatement ps = c.prepareStatement(sql);
			update  = ps.execute();

	    } 
	    catch (SQLException e) 
	    {
	        e.printStackTrace();
	    }
	      return update;
	}
	
	
	public boolean updatePorcentagemDaRotatividadeModa(int id_prof, double porcentagem_rotatividade_moda) {
		boolean update = false;
	    try 
	    {
	    	String sql = "update profissional set porcentagem_moda = '"+porcentagem_rotatividade_moda+"' where id_prof = "+id_prof+";";
			Connection c = conexao.getConnection();
			PreparedStatement ps = c.prepareStatement(sql);
			update  = ps.execute();

	    } 
	    catch (SQLException e) 
	    {
	        e.printStackTrace();
	    }
	      return update;
	}
	
	public HashMap<Integer, Integer> recuperarIdsEAreas()
	{
		HashMap<Integer, Integer> ids_e_areas = new HashMap<Integer, Integer>();
		
		try 
		{
			Statement stm = conexao.getConnection().createStatement();
			ResultSet consulta = stm.executeQuery("select id_prof, id_area from profissional;");
			
			while(consulta.next())
			{
			  ids_e_areas.put(consulta.getInt("id_prof"), consulta.getInt("id_area"));
			}
			
		} 
		
		catch (SQLException e) 
		{
			e.printStackTrace();
			System.out.println("Erro pegando ids e area em Profissionais no BD!!!");
			
		}
		return ids_e_areas;
	}
	
	public ArrayList<Integer> recuperarProfsPorArea(int id_area)
	{
		ArrayList<Integer> id_profs = new ArrayList<Integer>();
		
		try 
		{
			Statement stm = conexao.getConnection().createStatement();
			ResultSet consulta = stm.executeQuery("select id_prof from profissional where id_area ="+id_area+";");
			
			while(consulta.next())
			{
			  id_profs.add(consulta.getInt("id_prof"));
			}
			
		} 
		
		catch (SQLException e) 
		{
			e.printStackTrace();			
		}
		return id_profs;
	}
	
	public HashMap<Integer, String> recuperarIdsProfsECidades()
	{
		HashMap<Integer, String> ids_e_cidades = new HashMap<Integer, String>();
		
		try 
		{
			Statement stm = conexao.getConnection().createStatement();
			ResultSet consulta = stm.executeQuery("select id_prof, nome_cidade from profissional natural join Estado natural join Cidade where nome_cidade != 'nao declarado' and nome_estado = 'nao declarado';");
			
			while(consulta.next())
			{
				ids_e_cidades.put(consulta.getInt("id_prof"), consulta.getString("nome_cidade"));
			}
			
		} 
		
		catch (SQLException e) 
		{
			e.printStackTrace();
			System.out.println("Erro pegando ids e area em Profissionais no BD!!!");
			
		}
		return ids_e_cidades;
	}
	
	public boolean updateEstadoProf(int id_prof, int id_estado) {
		boolean update = false;
	    try 
	    {
	    	String sql = "update profissional set id_estado = '"+id_estado+"' where id_prof = "+id_prof+" and id_estado = 4;";
			Connection c = conexao.getConnection();
			PreparedStatement ps = c.prepareStatement(sql);
			update  = ps.execute();

	    } 
	    catch (SQLException e) 
	    {
	        e.printStackTrace();
	    }
	      return update;
	}
	
	
	
}
