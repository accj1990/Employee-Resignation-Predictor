package bd;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import conexao.Conexao;
import entidades.Formacao;

public class DatabaseFormacao
{
	
	private Conexao conexao;
	
	public DatabaseFormacao(Conexao con)
	{
		setConexao(con);
	}
	
	public Conexao getConexao() 
	{
		return conexao;
	}

	public void setConexao(Conexao conexao) 
	{
		this.conexao = conexao;
	}
	
	public boolean inserirFormacao(Formacao formacao) 
	{
		boolean inserir = false;
		try 
		{
			String sql = "INSERT INTO Formacao (id_instituicao, id_prof, id_grau, tempo_formacao) VALUES ('"+formacao.getId_instituicao()+"','"+formacao.getId_prof()+"','"+formacao.getId_grau() +"','"+formacao.getTempo_formacao()+"')" ;		
			Connection c = conexao.getConnection();
			PreparedStatement ps = c.prepareStatement(sql);
			ps.execute();
			inserir = true;

		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		return inserir;
	}

}
