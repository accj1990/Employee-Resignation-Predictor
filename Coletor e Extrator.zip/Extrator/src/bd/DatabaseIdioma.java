package bd;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import conexao.Conexao;
import entidades.Idioma;

public class DatabaseIdioma
{
	private Conexao conexao;
	
	public DatabaseIdioma(Conexao con)
	{
		setConexao(con);
	}
	
	public Conexao getConexao() 
	{
		return conexao;
	}

	public void setConexao(Conexao conexao) 
	{
		this.conexao = conexao;
	}

	public boolean inserirIdioma(Idioma idioma) 
	{
	
		boolean inserir = false;
		try 
		{
			String sql = "INSERT INTO Idioma (id_idioma, nome_idioma) VALUES ("+idioma.getId_idioma()+",'"+idioma.getNome_idioma()+ "')";		
			Connection c = conexao.getConnection();
			PreparedStatement ps = c.prepareStatement(sql);
			ps.execute();
			inserir = true;

		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		return inserir;
	}
	
	public int pegarIdIdioma(String nome_idioma) {
		int id_idioma = -1;
		try {
			Statement stm = conexao.getConnection().createStatement();
			ResultSet consulta = stm.executeQuery("SELECT id_idioma from Idioma where nome_idioma = '"+nome_idioma+"'");
			
			if(consulta.next())
			{
			  id_idioma = consulta.getInt("id_idioma");
			}
		} catch (SQLException e) 
		{
			e.printStackTrace();
			System.out.println("Erro pegando ID_idioma no BD!!!");
			
		}
		
		return id_idioma;
	}
	

}
