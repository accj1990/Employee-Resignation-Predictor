package bd;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import conexao.Conexao;
import entidades.Instituicao;

public class DatabaseInstituicao
{
	private Conexao conexao;
	
	public DatabaseInstituicao(Conexao con)
	{
		setConexao(con);
	}
	
	public Conexao getConexao() 
	{
		return conexao;
	}

	public void setConexao(Conexao conexao) 
	{
		this.conexao = conexao;
	}

	public boolean inserirInstituicao(Instituicao instituicao) {
		
		boolean inserir = false;
		try 
		{
			String sql = "INSERT INTO Instituicao (id_instituicao, nome_instituicao) VALUES ("+instituicao.getId_instituicao()+",'"+instituicao.getNome_instituicao()+ "')";		
			Connection c = conexao.getConnection();
			PreparedStatement ps = c.prepareStatement(sql);
			ps.execute();
			inserir = true;

		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		return inserir;
	}
	
	public int pegarIdInstituicao(String nome_instituicao) {
		int id_instituicao = -1;
		try {
			Statement stm = conexao.getConnection().createStatement();
			ResultSet consulta = stm.executeQuery("SELECT id_instituicao from Instituicao where nome_instituicao = '"+nome_instituicao+"'");
			
			if(consulta.next())
			{
				id_instituicao = consulta.getInt("id_instituicao");
			}
		} catch (SQLException e) 
		{
			e.printStackTrace();
			System.out.println("Erro pegando ID_instituicao no BD!!!");
			
		}
		
		return id_instituicao;
	}

}
