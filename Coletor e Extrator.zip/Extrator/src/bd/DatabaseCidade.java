package bd;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import entidades.Cidade;
import conexao.Conexao;
public class DatabaseCidade {

	private Conexao conexao;
	
	public DatabaseCidade(Conexao con)
	{
		setConexao(con);
	}
	
	public Conexao getConexao() 
	{
		return conexao;
	}

	public void setConexao(Conexao conexao) 
	{
		this.conexao = conexao;
	}
	public boolean inserirCidade(Cidade cidade) {
		
		boolean inserir = false;
		
		try 
			{
			String sql = "INSERT INTO Cidade (id_cidade, nome_cidade) VALUES ("+cidade.getId_cidade()+",'"+cidade.getNome_cidade()+"')";		
			Connection c = conexao.getConnection();
			PreparedStatement ps = c.prepareStatement(sql);
			ps.execute();
			inserir = true;

		} 
		catch (SQLException e) 
		{
				e.printStackTrace();
		}
		
		return inserir;
	}
	
	public int pegarIdCidade(String nome_cidade) {
		int id_cidade = -1;
		try {
			Statement stm = conexao.getConnection().createStatement();
			ResultSet consulta = stm.executeQuery("SELECT id_cidade from Cidade where nome_cidade = '"+nome_cidade+"'");
			
			if(consulta.next())
			{
			  id_cidade = consulta.getInt("id_cidade");
			}
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("Erro pegando ID_cidade no BD!!!");
			
		}
		
		return id_cidade;
	}
	

}
