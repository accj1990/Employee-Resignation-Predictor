package bd;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import conexao.Conexao;
import entidades.Competencia;

public class DatabaseCompetencia  
{
	private Conexao conexao;
	
	public DatabaseCompetencia(Conexao con)
	{
		setConexao(con);
	}
	
	public Conexao getConexao() 
	{
		return conexao;
	}

	public void setConexao(Conexao conexao) 
	{
		this.conexao = conexao;
	}

	public boolean inserirCompetencia(Competencia competencia) 
	{
		
		boolean inserir = false;
		try 
		{
			String sql = "INSERT INTO Competencia (id_competencia, nome_competencia) VALUES ("+competencia.getId_compentencia()+",'"+competencia.getNome_competencia() +"')";		
			Connection c = conexao.getConnection();
			PreparedStatement ps = c.prepareStatement(sql);
			ps.execute();
			inserir = true;

		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		return inserir;
	}
	
	public int pegarIdCompetencia(String nome_competencia) {
		int id_competencia = -1;
		try {
			Statement stm = conexao.getConnection().createStatement();
			ResultSet consulta = stm.executeQuery("SELECT id_competencia from Competencia where nome_competencia = '"+nome_competencia+"'");
			
			if(consulta.next())
			{
			  id_competencia = consulta.getInt("id_competencia");
			}
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("Erro pegando ID_Competencia no BD!!!");
			
		}
		
		return id_competencia;
	}



}
