package bd;

import conexao.Conexao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;


import entidades.Area;

public class DatabaseArea 
{
	private Conexao conexao;
	
	public DatabaseArea(Conexao con)
	{
		setConexao(con);
	}
	
	public Conexao getConexao() 
	{
		return conexao;
	}

	public void setConexao(Conexao conexao) 
	{
		this.conexao = conexao;
	}

	public boolean inserirArea(Area area) 
	{
		boolean inserir = false;
		try 
		{
			String sql = "INSERT INTO Area (id_area, nome_area, rotatividade_media, rotatividade_moda, rotatividade_mediana) "
					+ "VALUES ("+area.getId_area()+",'"+area.getNome_area()+ "','"+area.getRotatividade_media()+
					"','"+area.getRotatividade_moda()+"','"+area.getRotatividade_mediana()+"')";		
			Connection c = conexao.getConnection();
			PreparedStatement ps = c.prepareStatement(sql);
			ps.execute();
			inserir = true;

		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		return inserir;
	}
	
	public int pegarIdArea(String nome_area) {
		int id_area = -1;
		try 
		{
			Statement stm = conexao.getConnection().createStatement();
			ResultSet consulta = stm.executeQuery("SELECT id_area from Area where nome_area = '"+nome_area+"' ;");
			
			if(consulta.next())
			{
			  id_area = consulta.getInt("id_area");
			}
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
			System.out.println("Erro pegando ID_area no BD!!!");
			
		}
		
		return id_area;
	}
	

	public boolean updateRotatividadeMedia(int id_area, double rotatividade) 
	{
		boolean atualizado = false;
		try 
		{
			Connection c = conexao.getConnection();
			PreparedStatement ps = c.prepareStatement("update area set rotatividade_media = '"+rotatividade+"'where id_area = '"+id_area+"';");
			atualizado  = ps.execute();	
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
			System.out.println("Erro pegando ID_area no BD!!!");
			
		}
		return atualizado;
	}
	
	public boolean updateRotatividadeModa(int id_area, double rotatividade) 
	{
		boolean atualizado = false;
		try 
		{
			Connection c = conexao.getConnection();
			PreparedStatement ps = c.prepareStatement("update area set rotatividade_moda = '"+rotatividade+"'where id_area = '"+id_area+"';");
			atualizado  = ps.execute();	
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
			System.out.println("Erro pegando ID_area no BD!!!");
			
		}
		return atualizado;
	}
	
	public boolean updateRotatividadeMediana(int id_area, double rotatividade) 
	{
		boolean atualizado = false;
		try 
		{
			Connection c = conexao.getConnection();
			PreparedStatement ps = c.prepareStatement("update area set rotatividade_mediana = '"+rotatividade+"'where id_area = '"+id_area+"';");
			atualizado  = ps.execute();	
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
			System.out.println("Erro pegando ID_area no BD!!!");
			
		}
		return atualizado;
	}
	
	
	public HashMap<Integer, Integer> pegarMediasDeTrabalhoPorArea()
	{
		HashMap <Integer, Integer> ids_medias = new HashMap<Integer, Integer>();
		
		try 
		{
			Statement stm = conexao.getConnection().createStatement();
			ResultSet consulta = stm.executeQuery("select id_area, div(avg(tempo_trabalhado),12) from Profissional_Experiencia natural join Profissional group by id_area ;");
			
			while(consulta.next())
			{
				ids_medias.put(consulta.getInt("id_area"), consulta.getInt("div"));
			}
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
			System.out.println("Erro pegando dados do BD!!!");
			
		}
		return ids_medias;
	}
	
	public int pegarModasDeTrabalhoPorArea(int id_area)
	{
		
		int moda = 0; 
		try 
		{
			Statement stm = conexao.getConnection().createStatement();
			ResultSet consulta = stm.executeQuery("select div(tempo_trabalhado,12), count(tempo_trabalhado) from Profissional_Experiencia natural join Profissional where id_area = '"+id_area+"' group by id_area, tempo_trabalhado order by count desc;");
			
			double contador = 1;

			consulta.next();
			moda = consulta.getInt("div");
			int count = consulta.getInt("count");
			
			while(consulta.next())
			{
				if (count == consulta.getInt("count")) 
				{	
					moda+= consulta.getInt("div");
					contador++;
				}
				else
					break;
			}
			
			moda /= contador;
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
			System.out.println("Erro pegando dados do BD!!!");
			
		}
		return moda;
	}
	
	public int pegarMedianaDeTrabalhoPorArea(int id_area)
	{
		
		ArrayList<Integer> vetor = new ArrayList<Integer>();
		
		int mediana = 0;
		try 
		{
			Statement stm = conexao.getConnection().createStatement();
			ResultSet consulta = stm.executeQuery("select div(tempo_trabalhado,12) from Profissional_Experiencia natural join Profissional where id_area = '"+id_area+"' group by tempo_trabalhado order by tempo_trabalhado asc;");
			
			while(consulta.next())
			{
				vetor.add(consulta.getInt("div"));
			}
			
			int pos = vetor.size()/2;
			if (vetor.size() % 2 == 0)
			{
				mediana = ((vetor.get(pos-1) + vetor.get(pos)))/2;
			}
			else
			{
				mediana = vetor.get(pos);
			}		
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
			System.out.println("Erro pegando dados do BD!!!");
			
		}
		
	/*	Iterator it = vetor.iterator();
		while(it.hasNext())
		{
			System.out.print(" "+it.next().toString());
		}
		
		System.out.println("\nMEDIANA:  "+mediana);
	*/
		return mediana;
	}
	
	
	public HashMap<String, Integer> getAreas()
	{
		HashMap<String, Integer> areas = new HashMap<String, Integer>();
		
		try 
		{
			Statement stm = conexao.getConnection().createStatement();
			ResultSet consulta = stm.executeQuery("select id_area, nome_area from area;");
			
			while(consulta.next())
			{
				areas.put(consulta.getString("nome_area"), consulta.getInt("id_area"));
			}
		
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
			System.out.println("Erro pegando dados do BD!!!");
			
		}
	
		return areas;
	}
	
	
}
