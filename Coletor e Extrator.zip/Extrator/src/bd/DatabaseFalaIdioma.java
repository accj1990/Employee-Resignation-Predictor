package bd;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import conexao.Conexao;
import entidades.FalaIdioma;

public class DatabaseFalaIdioma
{

	private Conexao conexao;
	
	public DatabaseFalaIdioma(Conexao con)
	{
		setConexao(con);
	}
	
	public Conexao getConexao() 
	{
		return conexao;
	}

	public void setConexao(Conexao conexao) 
	{
		this.conexao = conexao;
	}
	public boolean inserirFalaIdioma(FalaIdioma falaidioma) {
		
		boolean inserir = false;
		try 
		{
			String sql = "INSERT INTO FalaIdioma (id_idioma, id_prof) VALUES ('"+falaidioma.getId_idioma()+"','"+falaidioma.getId_prof()+"')" ;		
			Connection c = conexao.getConnection();
			PreparedStatement ps = c.prepareStatement(sql);
			ps.execute();
			inserir = true;

		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		return inserir;
	}

}
