package bd;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import entidades.Estado;
import conexao.Conexao;


public class DatabaseEstado
{
	private Conexao conexao;
	
	public DatabaseEstado(Conexao con)
	{
		setConexao(con);
	}
	
	public Conexao getConexao() 
	{
		return conexao;
	}

	public void setConexao(Conexao conexao) 
	{
		this.conexao = conexao;
	}

	
	public boolean inserirEstado(Estado estado) 
	{
		boolean inserir = false;
		
		try 
		{
			String sql = "INSERT INTO Estado (id_estado, nome_estado) VALUES ("+estado.getId_estado()+",'"+estado.getNome_estado()+"')";		
			Connection c = conexao.getConnection();
			PreparedStatement ps = c.prepareStatement(sql);
			ps.execute();
			inserir = true;

		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		
		return inserir;
	}
	
	public int pegarIdEstado(String nome_estado) {
		int id_estado = -1;
		try {
			Statement stm = conexao.getConnection().createStatement();
			ResultSet consulta = stm.executeQuery("SELECT id_estado from Estado where nome_estado = '"+nome_estado+"'");
			
			if(consulta.next())
			{
			  id_estado = consulta.getInt("id_estado");
			}
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("Erro pegando ID_Estado no BD!!!");
			
		}
		
		return id_estado;
	}
	
	public int getIdEstado(String sigla) {
		int id_estado = -1;
		try {
			Statement stm = conexao.getConnection().createStatement();
			ResultSet consulta = stm.executeQuery("SELECT id_estado from Estado where sigla = '"+sigla+"'");
			
			if(consulta.next())
			{
			  id_estado = consulta.getInt("id_estado");
			}
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("Erro pegando ID_Estado no BD!!!");
			
		}
		
		return id_estado;
	}

}
