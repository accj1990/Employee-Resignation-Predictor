package bd;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import conexao.Conexao;
import entidades.Experiencia;


public class DatabaseExperiencia
{
	private Conexao conexao;
	
	public DatabaseExperiencia(Conexao con)
	{
		setConexao(con);
	}
	
	public Conexao getConexao() 
	{
		return conexao;
	}

	public void setConexao(Conexao conexao) 
	{
		this.conexao = conexao;
	}

	public boolean inserirExperiencia(Experiencia experiencia) 
	{
	
		boolean inserir = false;
		try 
		{
			String sql = "INSERT INTO Experiencia (id_experiencia, nome_experiencia) VALUES ("+experiencia.getId_experiencia()+",'"+experiencia.getNome_experiencia()+"')";		
			Connection c = conexao.getConnection();
			PreparedStatement ps = c.prepareStatement(sql);
			ps.execute();
			inserir = true;

		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		return inserir;
	}
	
	public int pegarIdExperiencia(String nome_experiencia) {
		int id_experiencia = -1;
		try {
			Statement stm = conexao.getConnection().createStatement();
			ResultSet consulta = stm.executeQuery("SELECT id_experiencia from Experiencia where nome_experiencia = '"+nome_experiencia+"'");
			
			if(consulta.next())
			{
			  id_experiencia = consulta.getInt("id_experiencia");
			}
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("Erro pegando ID_Estado no BD!!!");
			
		}
		
		return id_experiencia;
	}
	
}
