package bd;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import conexao.Conexao;
import entidades.Profissional_Experiencia;

public class DatabaseProfissionalExperiencia
{

	private Conexao conexao;
	
	public DatabaseProfissionalExperiencia(Conexao con)
	{
		setConexao(con);
	}
	
	public Conexao getConexao() 
	{
		return conexao;
	}

	public void setConexao(Conexao conexao) 
	{
		this.conexao = conexao;
	}

	public boolean inserirProfissionalExperiencia(Profissional_Experiencia prof_exp) 
	{
		boolean inserir = false;
		try 
		{
			String sql = "INSERT INTO Profissional_Experiencia VALUES ('"+prof_exp.getId_exp()+"','"+
					prof_exp.getId_prof()+"','"+prof_exp.getTempo_trabalhado()+"')";		
			Connection c = conexao.getConnection();
			PreparedStatement ps = c.prepareStatement(sql);
			ps.execute();
			inserir = true;

		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		return inserir;
	}
	
	public ArrayList<Integer> pegarTemposExperiencias(int id_profissional) 
	{
		ArrayList<Integer> tempo_experiencias =  new ArrayList<Integer>();
		
		try 
		{
			Statement stm = conexao.getConnection().createStatement();
			ResultSet consulta = stm.executeQuery("SELECT tempo_trabalhado from Profissional_Experiencia where id_prof = '"+id_profissional+"'");
			
			while(consulta.next())
			{
			  tempo_experiencias.add(consulta.getInt("tempo_trabalhado"));
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("Erro pegando tempo_trabalhado em Profissionais_Experiencias no BD!!!");
			
		}
		
		return tempo_experiencias;
	}
	
	
	public ArrayList<Integer> pegarTemposExperienciasArea(int id_prof) 
	{
		ArrayList<Integer> tempo_experiencias =  new ArrayList<Integer>();
		
		try 
		{
			Statement stm = conexao.getConnection().createStatement();
			ResultSet consulta = stm.executeQuery("SELECT tempo_trabalhado from Profissional_Experiencia where id_prof = '"+id_prof+"'");
			
			while(consulta.next())
			{
			  tempo_experiencias.add(consulta.getInt("tempo_trabalhado"));
			}
			
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();		
		}
		
		return tempo_experiencias;
	}
	
	
	
	

	
}
