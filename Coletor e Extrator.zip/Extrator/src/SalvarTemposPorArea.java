import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

import bd.DatabaseArea;
import bd.DatabaseEstado;
import bd.DatabaseProfissionais;
import bd.DatabaseProfissionalExperiencia;
import conexao.Conexao;


public class SalvarTemposPorArea {

	public static DatabaseArea base_area;
	public static DatabaseProfissionais base_profissionais;
	public static DatabaseProfissionalExperiencia base_profissionalexperiencia;
	public static DatabaseEstado estados;
	
	public static void main(String[] args) throws IOException 
	{
		//carregarDadosTempoDoBD();
		
		//alterarExtensao("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados");
		
		//arrumarTodosOsCSVs()
		
		//confere(); // conferir todos os arquivos
		
		
		// arrumar estados
		carregar();
		arrumarEstados();
		
		
	}
	
	public static void arrumarEstados() throws IOException
	{
		HashMap<Integer, String> ids_e_cidades = base_profissionais.recuperarIdsProfsECidades();
		HashMap<String, String> cidades_padro = new HashMap<String, String>();
		File f = new File("C:\\Users\\Carol\\Desktop\\cidades_padronizadas.csv");
		HashMap<String, Integer> ci_id = new HashMap<String, Integer>();
		
		
		BufferedReader in = new BufferedReader(new FileReader(f));

		String c = in.readLine();
		
		while(c != null)
		{
			//System.out.println(c);
			String [] dados = c.split(";");
			//System.out.println(dados[0] + " "+estados.getIdEstado(dados[1]));
			c = in.readLine();
			if (ids_e_cidades.containsValue(dados[0]))
			{
			  // System.out.println(dados[0] + " "+estados.getIdEstado(dados[1]));
			   ci_id.put(dados[0],estados.getIdEstado(dados[1])); 
			   
			}
		}
		
		for (String ci: ci_id.keySet())
		{
			for (Integer e: ids_e_cidades.keySet())
			{
				if (ids_e_cidades.get(e).equals(ci))
				{
					base_profissionais.updateEstadoProf(e, ci_id.get(ci));
				}
			}
		}
		
		
	}
	
	
	
	
	
	public static void confere()
	{
		File pasta0 = new File("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados");
		File pasta1 = new File("C:\\Users\\Carol\\Desktop\\analisados");
		
		File afile[] = pasta0.listFiles();
		File afile2[] = pasta1.listFiles();

		
		int i = 0;
		int l = 0;
		boolean flag = false;

		for (int j = afile.length; i < j; i++) 
		{
			File arquivo = afile[i];
			flag = false;

			//System.out.println("###### "+arquivo.getName()+" ###### ");

			for (int k = afile2.length; l < k; l++) 
			{
				File arquivo2 = afile2[l];
				if (arquivo.getName().equals(arquivo2.getName()))
				{
					flag = true;
					break;
				}
				//System.out.println(""+arquivo2.getName());
				
			}
			
			
			if (!flag)
			{
				System.out.println(arquivo.getName());
			}
			l = 0;
			//System.out.println("###### "+arquivo.getName()+" ###### ");

		}
		
		
		
		

	}
	
	
	public static void arrumarCSV(String arquivo) throws IOException
	{
		File file = new File(arquivo);
		File saida = new File("C:\\Users\\Carol\\Desktop\\"+file.getName());
		
		Scanner s = new Scanner (file);
		
		FileWriter gravar = new FileWriter(saida);
		BufferedWriter bw = new BufferedWriter(gravar); 
		
		int i = 2;
		
		bw.write("tempo_meses ; tempo_anos ; anos");
		bw.newLine();
		String valor;
		while(s.hasNext())
		{
			valor = s.next();
			Integer arredondado = (Integer.parseInt(valor))/12;
			bw.write(valor+";=A"+i+"/12;"+arredondado);
			bw.newLine();	
			//System.out.println(i+ " "+s.next());
			
			
			i++;
		}

		bw.close();

	}
	
	
	
	
	public static void alterarExtensao(String diretorio)
	{
		File file = new File(diretorio);
		File afile[] = file.listFiles();
		int i = 0;
		String nom = "";
		for (int j = afile.length; i < j; i++) 
		{
			File arquivo = afile[i];
			nom = arquivo.getAbsolutePath();
			arquivo.renameTo(new File(nom.replace(".txt",".csv")));
			//System.out.println(arquivo.getAbsolutePath());
		}
	}
	
	public static void carregar()
	{
		Conexao c = new Conexao("Teste");
		base_profissionais = new DatabaseProfissionais(c);
		estados = new DatabaseEstado(c);
	}
	
	
	
	public static void carregarDadosTempoDoBD() throws IOException
	{
		Conexao c = new Conexao("Teste");
		base_profissionais = new DatabaseProfissionais(c);
		base_area = new DatabaseArea(c);
		base_profissionalexperiencia = new DatabaseProfissionalExperiencia(c);
		
		HashMap<String, Integer> areas = base_area.getAreas();
		
		for (String e: areas.keySet())
		{
			System.out.print("Area: "+e+" status: ");
			ArrayList<Integer> id_profs = base_profissionais.recuperarProfsPorArea(areas.get(e));
			salvarAreaeTemposNoArquivo(e, id_profs);
		}
	}
	
	public static void salvarAreaeTemposNoArquivo(String area, ArrayList <Integer> id_profs) throws IOException
	{
		if(!new File("C:\\Users\\Carol\\Desktop\\TemposPorArea\\"+area+".txt").exists())
		{
			File f = new File ("C:\\Users\\Carol\\Desktop\\TemposPorArea\\"+area+".txt");
			FileWriter gravar = new FileWriter(f);
			BufferedWriter bw = new BufferedWriter(gravar); 
		
			for (int i = 0; i < id_profs.size(); i++)
			{
				ArrayList<Integer> tempos = base_profissionalexperiencia.pegarTemposExperienciasArea(id_profs.get(i));
				String texto = "";
				for (int k = 0; k < tempos.size(); k++)
				{
					texto = ""+tempos.get(k);
					bw.write(texto);
					bw.newLine();
				}

			
			}
		
			bw.close();
			System.out.print("Arquivo gerado com sucesso!\n");
		}
		else
		{
			System.out.print("Arquivo ja gerado!\n");
		}
	}
	
	public static void arrumarTodosOsCSVs()
	{
		//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\administracao de servicos.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\administracao agricola.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\administracao governamental.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\agricultura.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\alimentos e bebidas.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\animacao.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\arquitetura e planejamento.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\arrecadacao de recursos.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\artes cenicas.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\artes e artesanato.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\atacado.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\atendimento ao consumidor.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\atendimento medico e hospitalar.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\atendimento medico psiquiatrico.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\atividades parlamentares.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\automacao industrial.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\aviacao e aeroespacial.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\bancos de investimento.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\bancos.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\belas-artes.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\bens de consumo.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\bibliotecas.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\biotecnologia.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\capital de risco e participacoes privadas.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\cinema e filmes.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\comercio e desenvolvimento internacional.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\composicao e revisao de textos.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\construcao de ferrovia.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\construcao naval.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\construcao.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\consultoria de gerenciamento.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\contabilidade.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\cosmetica.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\defesa e espaco.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\desenvolvimento de programas.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\design grafico.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\design.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\dispositivos medicos.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\editoracao.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\educacao a distancia.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\embalagens e recipientes.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\engenharia civil.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\engenharia mecanica ou industrial.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\ensino fundamental,medio.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\ensino superior.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\entrega de encomendas e fretes.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\entretenimento.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\esportes.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\execucao da lei.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\filantropia.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\fotografia.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\gabinete presidencial.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\gestao de investimentos.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\gestao educacional.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\hardware.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\hotelaria.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\imobiliario.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\imoveis comerciais.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\imoveis.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\importacao e exportacao.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\impressao.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\industria automotiva.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\industria farmaceutica.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\industria quimica.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\industria textil.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\instalacoes e servicos de recreacao.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\instituicoes religiosas.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\internet.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\jogos de azar.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\jogos de computador.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\jornais.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\judiciario.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\laticinios.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\lazer, viagens e turismo.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\linhas aereas,aviacao.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\logistica e cadeia de suprimentos.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\manufatura de eletroeletronicos.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\marketing e publicidade.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\materiais de construcao.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\materiais esportivos.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\medicina alternativa.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\mercados de capital.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\midia de difusao.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\midia online.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\militar.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\mineracao e metais.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\moveis.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\museus e instituicoes.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\musica.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\nanotecnologia.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\nao declarado.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\organizacao civica e social.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\organizacoes de pesquisa e orientacao.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\papel e produtos florestais.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\pesca.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\pesquisa de mercado.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\pesquisa.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\petroleo e energia.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\plastico.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\politica publica.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\pratica juridica.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\pratica medica.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\producao de midia.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\papel e produtos florestais.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\produtos alimenticios.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\produtos de luxo e joias.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\produtos eletronicos.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\recrutamento e selecao.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\recursos humanos.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\recursos renovaveis e meio ambiente.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\rede sem fio.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\redes.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\relacoes governamentais.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\relacoes internacionais.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\relacoes publicas e comunicacoes.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\resolucao alternativa de litigios.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\restaurantes.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\roupas e moda.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\saude, bem-estar e educacao fisica.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\seguranca de redes e computadores.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\seguranca e investigacoes.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\seguranca publica.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\seguros.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\semicondutores.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\servicos ambientais.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\servicos da informacao.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\servicos financeiros.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\servicos juridicos.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\servicos para eventos.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\servicos publicos.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\software.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\supermercados.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\suprimentos e equipamentos comerciais.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\tabaco.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\tecnologia da informacao e servicos.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\telecomunicacoes.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\terceirizacao e offshoring.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\traducao e localizacao.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\transporte maritimo.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\transporte,caminhoes,trens.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\treinamento a distancia.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\treinamento e orientacao profissional.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\varejo.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\veterinaria.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\vidro, ceramica e concreto.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\vinhos e destilados.csv")
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\armazenagem.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\gestao de organizacao sem fins lucrativos.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\maquinario.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\organizacao politica.csv");
				//arrumarCSV("C:\\Users\\Carol\\Desktop\\TemposPorAreaLimitados\\servicos individuais e familiares.csv");
	}
	
	
}
