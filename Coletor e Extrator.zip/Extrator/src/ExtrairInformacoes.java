import java.io.File;
import java.io.IOException;
import java.text.Normalizer;
import java.util.HashMap;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import conexao.Conexao;
import bd.*;
import entidades.*;
import entidadescoleta.*;


public class ExtrairInformacoes 
{
	public static String path = System.getProperty("user.home")+"\\Desktop\\Paginas\\";
	public static DatabaseProfissionais base_profissionais;
	public static DatabaseArea base_area;
	public static DatabaseCidade base_cidade;
	public static DatabaseEstado base_estado;
	public static DatabaseCompetencia base_competencia;
	public static DatabaseExperiencia base_experiencia;
	public static DatabaseIdioma base_idioma;
	public static DatabaseFalaIdioma base_falaidioma;
	public static DatabaseInstituicao base_instituicao;
	public static DatabaseFormacao base_formacao;
	public static DatabaseGrauFormacao base_grau;
	public static DatabaseProfissionalCompentencia base_profissionalcompetencia; 
	public static DatabaseProfissionalExperiencia base_profissionalexperiencia;
	public static int id_area = 1, id_localidade = 1, id_cidade = 1, id_estado = 1, 
						id_compentencia = 1, id_experiencia = 1, id_idioma = 1, id_instituicao = 1, id_grau = 1;
	
	public static void main(String [] args)
	{
		Conexao c = new Conexao("Teste");
		Conexao c2 = new Conexao("Coletor");
		DatabaseColetor base = new DatabaseColetor(c2);
		HashMap <Integer, Link> brasileiros = base.pegarPaginasBrasileiras();
		
		base_profissionais = new DatabaseProfissionais(c);
		base_area = new DatabaseArea(c);
		base_cidade = new DatabaseCidade(c);
		base_estado = new DatabaseEstado(c);
		base_competencia = new DatabaseCompetencia(c);
		base_experiencia = new DatabaseExperiencia(c);
		base_idioma = new DatabaseIdioma(c);
		base_falaidioma = new DatabaseFalaIdioma(c);
		base_instituicao = new DatabaseInstituicao(c);
		base_formacao = new DatabaseFormacao(c);
		base_grau = new DatabaseGrauFormacao(c);
		base_profissionalcompetencia = new DatabaseProfissionalCompentencia(c);
		base_profissionalexperiencia = new DatabaseProfissionalExperiencia(c);
	
		File diretorio = new File(path);
			
		if (diretorio.exists() && diretorio.length() > 0)
		{
			File f;
			Document doc;
					
			for(Integer k: brasileiros.keySet())
			{
				f = new File(path+"\\"+k+" - "+brasileiros.get(k).getNome()+".html");
				
				if (f.exists())
				{
					try
					{
						doc = Jsoup.parse(f,"UTF-8");
						if(doc.getElementById("experience")!= null)
						{
							System.out.println("######################### Profissional : "+f.getName()+" ###########################");
							
							
						    int id_area = extrairArea(doc);
							int cidadexestado[] = extrairEstadoECidade(doc);
							int atual = extrairAtual(doc);
							int anterior = extrairAnterior(doc);
							int conexoes = extrairConexoes(doc);
							
							Profissional p = new Profissional(k,brasileiros.get(k).getNome(),"", id_area, cidadexestado[0], cidadexestado[1] , 0, 0, atual, anterior, 0, 0, conexoes, 0, 0,0,0);
							base_profissionais.inserirProfissional(p);
							
							int total_idiomas = extrairIdioma(doc, p.getId());
							
							int total_competencias = extrairCompetencia(doc, p.getId());
							int total_experiencias = extrairExperiencia(doc, p.getId());
							int [] dados_formacao = extrairFormacao(doc, p.getId());
							
							String cargo = extrairCargo(doc);
					
							base_profissionais.updateTotalIdiomas(p, total_idiomas);
							base_profissionais.updateTotalCompetencias(p, total_competencias);
							base_profissionais.updateTotalExperiencias(p, total_experiencias);
							base_profissionais.updateTotalFormacao(p, dados_formacao[0]);
							base_profissionais.updateTempoFormacao(p,dados_formacao[1]);
							base_profissionais.updateCargo(p, cargo);
							
							
							
							System.out.println("####################################################################################");						
						}						
								
					}
					catch(IOException e)
					{
						System.out.println(" ERRO lendo o arquivo! " +f.getAbsolutePath());
						System.exit(0);
					}
				}
				
			}
		}
		
		System.out.println("Fim da extracao");
	}
	
	public static int extrairArea(Document doc)
	{
		Element a = doc.getElementById("demographics").select("dt").last();
		String nome_area ="nao declarado";
		int id_ar = -1;
		
		if (a != null)
		{
			a = doc.getElementById("demographics").select("dd.descriptor").last();
			if (a!= null)
			{
				if (!a.text().equals("") && !a.text().equals(" ") && (!a.text().contains("Brasil") || !a.text().contains("Brasil")))
				{	
					nome_area = removeAcentos(a.text());
				}
				else
				{
					nome_area = "nao declarado";
				}
			}
			else
			{
				nome_area = "nao declarado";
			}
		}
		
		Area area = new Area(id_area, nome_area.trim().toLowerCase(),0,0,0);
		if (base_area.inserirArea(area))
		{
			id_area++;
		}
		id_ar = base_area.pegarIdArea(area.getNome_area().trim());
		
		//System.out.println(nome_area);
		return id_ar;
	}

	//###############################################################################################################
	public static int[] extrairEstadoECidade(Document doc)
	{
		int [] dados = new int[2];
		Elements localidade = doc.getElementsByClass("profile-overview-content").select("span.locality");
		String cidade ="nao declarado";
		String estado ="nao declarado";
		
		if (localidade != null)
		{
			String temp[] = removeAcentos(localidade.text()).split(",");
				
				if (temp.length == 2)
				{
					String temp2[];
					if (temp[0].contains(" e "))
					{
						temp2 = temp[0].split(" e ");
						cidade = temp2[0];
						estado = temp2[1];
						
						if (estado.equals("Regiao"))
						{
							estado = "nao declarado";
						}
						
					}
					
				}
				else if (temp.length == 3)
				{
					cidade = temp[0];
					estado = temp[1];
					
					if (estado.equals(""))
					{
						estado = "nao declarado";
					}
					else if (cidade.equals(""))
					{
						cidade = "nao declarado";
					}
					else if(cidade.equals("") && estado.equals(""))
					{
						cidade = "nao declarado";
						estado = "nao declarado";
					}
				
				}		
		}
		estado = estado.trim().toLowerCase();
		cidade = cidade.trim().toLowerCase();
		
		Estado estado_declarado = new Estado(id_estado, estado);
		if (base_estado.inserirEstado(estado_declarado))
		{
			id_estado++;
		}
	
		dados[1] = base_estado.pegarIdEstado(estado);
		
		Cidade cidade_declarada = new Cidade(id_cidade,cidade, id_estado);
		if (base_cidade.inserirCidade(cidade_declarada))
		{
			id_cidade++;
		}
		
		dados[0]= base_cidade.pegarIdCidade(cidade);
		
		return dados;
		
	}
	
	public static int extrairIdioma(Document doc, int id_profissional)
	{
		Element ul_linguagens = doc.getElementById("languages");
		int total_idiomas = 0;
		Idioma idioma ;
		int id_idi = -1;
		FalaIdioma falaidioma;
		if (ul_linguagens != null)
		{
			for (Element li_linguagens: ul_linguagens.select("li.language"))
			{
				Elements nome_linguagem = li_linguagens.select("div.wrap").select("h4.name");
				//System.out.println(nome_linguagem.text());
				
				
				if (nome_linguagem.text().contains(",") || nome_linguagem.text().contains(" "))
				{
					String dados [];
					if (nome_linguagem.text().contains(","))
					{
						dados = nome_linguagem.text().split(",");
						for (int i = 0; i< dados.length; i++)
						{
							if (dados[i].contains(" "))
							{
								dados = dados[i].split(" ");
								
								idioma = new Idioma(id_idioma,removeAcentos(dados[0]).trim().toLowerCase());
								
								if (base_idioma.inserirIdioma(idioma))
								{
									id_idioma++;
								}
								id_idi = base_idioma.pegarIdIdioma(idioma.getNome_idioma());
								falaidioma = new FalaIdioma(id_profissional, id_idi);
								base_falaidioma.inserirFalaIdioma(falaidioma);
								total_idiomas++;
							}
							else
							{	
								idioma = new Idioma(id_idioma,removeAcentos(dados[i]).trim().toLowerCase());
							
								if (base_idioma.inserirIdioma(idioma))
								{
									id_idioma++;
								}
								id_idi = base_idioma.pegarIdIdioma(idioma.getNome_idioma());
								falaidioma = new FalaIdioma(id_profissional, id_idi);
								base_falaidioma.inserirFalaIdioma(falaidioma);
								total_idiomas++;
							}
						}
					}
					else
					{
						dados = nome_linguagem.text().split(" ");
						
						idioma = new Idioma(id_idioma,removeAcentos(dados[0]).trim().toLowerCase());
						if (base_idioma.inserirIdioma(idioma))
						{
							id_idioma++;
						}
						id_idi = base_idioma.pegarIdIdioma(idioma.getNome_idioma());
						falaidioma = new FalaIdioma(id_profissional, id_idi);
						base_falaidioma.inserirFalaIdioma(falaidioma);
						total_idiomas++;
						
					}
				}
				else
				{
					idioma = new Idioma(id_idioma,removeAcentos(nome_linguagem.text()).trim().toLowerCase());
					if (base_idioma.inserirIdioma(idioma))
					{
						id_idioma++;
					}
					id_idi = base_idioma.pegarIdIdioma(idioma.getNome_idioma());
					falaidioma = new FalaIdioma(id_profissional, id_idi);
					base_falaidioma.inserirFalaIdioma(falaidioma);
					total_idiomas++;
				}
			}
		}
		
		return total_idiomas;
	}
	
	@SuppressWarnings("unused")
	public static int [] extrairFormacao(Document doc, int id_profissional)
	{
		int dados[] = new int [2];
		int contador_formacoes = 0; 
		int total_tempo_formacoes = 0;
		int tempo_formacao = 0;
		int id_inst = -1;
		int id_gr = -1;
		Instituicao inst;
		Element section = doc.getElementById("education"); 
		String escola ="nao declarado";
		String grau_str ="nao declarado";
		boolean flag_tempo_grau = false;
		
		if(section != null)
		{
			if (!section.text().equals(""))
			{
				Elements instituicoes = section.select("ul.schools");
				
				if (instituicoes != null)
				{
					
					for(Element instituicao: instituicoes.select("li.school"))
					{
						contador_formacoes++;
						escola = instituicao.select("h4.item-title").text();
						Elements grau = instituicao.select("h5.item-subtitle");
						Elements datas = instituicao.select("div.meta").select("span.date-range");
						
						if(escola.equals("") || escola.equals(" "))
						{
							escola = "nao declarado"; 
						}
						
						inst = new Instituicao(id_instituicao, removeAcentos(escola).toLowerCase().replaceAll ("[^A-Za-z0-9]"," ").trim());
						if (base_instituicao.inserirInstituicao(inst))
						{
							id_instituicao++;
							contador_formacoes++;
						}
						
						if(datas != null)
						{
							flag_tempo_grau = true;
							
							String [] tempo = (instituicao.select("div.meta").select("span.date-range").text().replace(" ", "-")).split("-");
							if (tempo.length == 3)
							{
								if (AllisDigito(tempo[2]) && AllisDigito(tempo[0]))
								{
									tempo_formacao = (Integer.parseInt(tempo[2]) - Integer.parseInt(tempo[0]))*12;
								}
							}
						}
						
						if (grau!= null)
						{
							grau_str = removeAcentos(grau.text());
							if (!grau_str.equals(""))
							{	
								if(!flag_tempo_grau)
								{	
									if(grau_str.contains("Tecnico") || grau_str.contains("tecnico"))
									{
										tempo_formacao+= (2*12);
									}
									else if (grau_str.contains("Bacharel") || grau_str.contains("Bacharelado") 
										|| grau_str.contains("bacharel") || grau_str.contains("bacharelado"))
									{
										tempo_formacao+= (5*12);
									}
									else if(grau_str.contains("Doutor") || grau_str.contains("Doutorado") 
										|| grau_str.contains("doutor") || grau_str.contains("doutorado"))
									{
										tempo_formacao+= (4*12);
									}
								}
							}
							else
							{
								grau_str = "nao declarado";
							}
						}
						else if (grau == null || grau_str.equals("") || grau_str.equals(" "))
						{
							grau_str = "nao declarado";
						}
						
						total_tempo_formacoes+= tempo_formacao;
						Grau_Formacao grau_formacao = new Grau_Formacao(id_grau, removeAcentos(grau_str).toLowerCase());
						if (base_grau.inserirGrauFormacao(grau_formacao))
						{
							id_grau++;
						}
						
						id_gr = base_grau.pegarIdGrau(grau_formacao.getNome_grau());
						id_inst = base_instituicao.pegarIdInstituicao(inst.getNome_instituicao());
						Formacao formacao = new Formacao(id_inst, id_profissional, id_gr, tempo_formacao);
						base_formacao.inserirFormacao(formacao);
					}
				}
				else
				{
					escola = "nao declarado";
					grau_str = "nao declarado";
					
					inst = new Instituicao(-1, removeAcentos(escola).toLowerCase());
					base_instituicao.inserirInstituicao(inst);
					
					total_tempo_formacoes+= tempo_formacao;
					
					Grau_Formacao grau_formacao = new Grau_Formacao(id_grau, grau_str.toLowerCase());
					if (base_grau.inserirGrauFormacao(grau_formacao))
					{
						id_grau++;
					}
					
					id_gr = base_grau.pegarIdGrau(grau_formacao.getNome_grau());
					id_inst = base_instituicao.pegarIdInstituicao(inst.getNome_instituicao());
					
					Formacao formacao = new Formacao(id_inst, id_profissional, id_gr, tempo_formacao);
					base_formacao.inserirFormacao(formacao);
				}
			}
		
		}
		else
		{
			inst = new Instituicao(id_instituicao, removeAcentos(escola).toLowerCase());
			if (base_instituicao.inserirInstituicao(inst))
			{
				id_instituicao++;
			}
			
			total_tempo_formacoes+= tempo_formacao;
			
			Grau_Formacao grau_formacao = new Grau_Formacao(id_grau, grau_str.toLowerCase());
			if (base_grau.inserirGrauFormacao(grau_formacao))
			{
				id_grau++;
			}
			
			id_gr = base_grau.pegarIdGrau(grau_formacao.getNome_grau());
			id_inst = base_instituicao.pegarIdInstituicao(inst.getNome_instituicao());
			
			Formacao formacao = new Formacao(id_inst, id_profissional, id_gr, tempo_formacao);
			base_formacao.inserirFormacao(formacao);
		}

		dados[0] = contador_formacoes;
		dados[1] = tempo_formacao;
		
		return dados;
	}
	
	public static int extrairExperiencia(Document doc, int id_profissional)
	{
		int total_experiencias = 0;
		Elements experiencia = null;
		
		if (doc.getElementById("experience")!= null)
		{	
			experiencia = doc.getElementById("experience").children();
		}
		Elements ul_experiencias;
		Elements titulo_experiencia;
		Elements tempo_experiencia;
		String flag = "";
		int meses = 0; int anos = 0;
		
		if (experiencia != null)
		{
			ul_experiencias = experiencia.select("ul.positions");
			
			for(Element li_experiencia:ul_experiencias.select("li.position"))
			{
				titulo_experiencia = li_experiencia.select("h4.item-title");
				tempo_experiencia = li_experiencia.select("div.meta").select("span.date-range");
				
				if (titulo_experiencia != null)
				{	
					if (tempo_experiencia.text().contains("(") && tempo_experiencia.text().contains(")"))
					{
						String informacao [] = tempo_experiencia.text().substring(tempo_experiencia.text().indexOf("(") + 1, 
							tempo_experiencia.text().indexOf(")")).split(" ");
					
						if (informacao.length == 2)
						{
							if (informacao[1].equals("anos")|| informacao[1].equals("ano"))
							{
								anos = Integer.parseInt(informacao[0]);
								anos = anos * 12;
								flag = "ano";
							}
							else if (informacao[1].equals("meses")|| informacao[1].equals("m�s"))
							{
								meses = Integer.parseInt(informacao[0]);
								flag = "mes";
							}
						}
						else if (informacao.length == 4)
						{
							if (informacao[1].equals("anos")|| informacao[1].equals("ano")) 
							{
								anos = Integer.parseInt(informacao[0]);
								anos = anos * 12;
								flag = "ano";

							}
							if (informacao[3].equals("meses")|| informacao[3].equals("m�s"))
							{
								meses = Integer.parseInt(informacao[2]);
							}
							meses = meses + anos;
							flag = "mes";
						}
					
					
						if (flag.equals("mes"))
						{
							if (meses > 0)
							{	Experiencia exp = new Experiencia(id_experiencia, removeAcentos(titulo_experiencia.text()).trim().toLowerCase());
								if (base_experiencia.inserirExperiencia(exp))
								{
									id_experiencia++;
								}
								int id_expe = base_experiencia.pegarIdExperiencia(exp.getNome_experiencia());
								Profissional_Experiencia prof_exp = new Profissional_Experiencia(id_expe, id_profissional, meses);
								base_profissionalexperiencia.inserirProfissionalExperiencia(prof_exp);
								total_experiencias++;
								//System.out.println(id_profissional+" "+id_experiencia+" "+titulo_experiencia.text() + " : "+tempo_experiencia.text());
							}
						}
						else if (flag.equals("ano"))
						{
							if (anos > 0)
							{
								Experiencia exp = new Experiencia(id_experiencia, removeAcentos(titulo_experiencia.text()).trim().toLowerCase());
								if (base_experiencia.inserirExperiencia(exp))
								{
									id_experiencia++;
								}
								int id_expe = base_experiencia.pegarIdExperiencia(exp.getNome_experiencia());
								Profissional_Experiencia prof_exp = new Profissional_Experiencia(id_expe, id_profissional, anos);
								base_profissionalexperiencia.inserirProfissionalExperiencia(prof_exp);
								total_experiencias++;
								//System.out.println(id_profissional+" "+id_experiencia+" "+titulo_experiencia.text() + " : "+tempo_experiencia.text());
							}
						}
					}
					else
					{
						if (anos > 0)
						{	
							Experiencia exp = new Experiencia(id_experiencia, "nao declarado");
							if (base_experiencia.inserirExperiencia(exp))
							{
								id_experiencia++;
							}
							int id_expe = base_experiencia.pegarIdExperiencia(exp.getNome_experiencia());
							Profissional_Experiencia prof_exp = new Profissional_Experiencia(id_expe, id_profissional, anos);
							base_profissionalexperiencia.inserirProfissionalExperiencia(prof_exp);
							total_experiencias++;
						}
					}
					
				}
				
			}	
		}
		else
		{
			if (anos > 0)
			{	
				Experiencia exp = new Experiencia(id_experiencia, "nao declarado");
				if (base_experiencia.inserirExperiencia(exp))
				{
					id_experiencia++;
				}
				int id_expe = base_experiencia.pegarIdExperiencia(exp.getNome_experiencia());
				Profissional_Experiencia prof_exp = new Profissional_Experiencia(id_expe, id_profissional, anos);
				base_profissionalexperiencia.inserirProfissionalExperiencia(prof_exp);
				total_experiencias++;
			}
		}
		return total_experiencias;
	}
	
	public static int extrairCompetencia(Document doc, int id_profissional)
	{
		Elements ul_competencias = doc.getElementsByClass("profile-section").select("section#skills").select("ul.pills");
		int total_competencias = 0;
		int id_comp = -1;
		if (ul_competencias != null)
		{
			for (Element li: ul_competencias.select("li.skill"))
			{
				if(!li.select("a").select("span.wrap").text().equals("")
						&& !li.select("a").select("span.wrap").text().equals(" "))
				{
					total_competencias++;
					Competencia competencia = new Competencia(id_compentencia, removeAcentos(li.select("a").select("span.wrap").text()).trim().toLowerCase());
					if (base_competencia.inserirCompetencia(competencia))
					{
						id_compentencia++;
					}
					id_comp = base_competencia.pegarIdCompetencia(competencia.getNome_competencia());
					
					ProfissionalCompetencia prof_comp = new ProfissionalCompetencia(id_profissional, id_comp);
					base_profissionalcompetencia.inserirProfissionalCompetencia(prof_comp);
				}
			}
		}
		
		return total_competencias;
	}
	
	public static String extrairCargo(Document doc)
	{
		String cargo = "Nao declarado";
		Elements elemento_cargo = doc.getElementsByClass("profile-overview-content").select("p.headline");
		
		if (elemento_cargo != null)
		{
			cargo = (removeAcentos(elemento_cargo.text()).toLowerCase()).replaceAll ("[^A-Za-z0-9]"," ").trim(); 
			
			if (cargo.equals("") || cargo.equals(" "))
			{
				cargo = "Nao declarado";
			}
		}
	
		return cargo;
	}
	
	public static int extrairAtual(Document doc)
	{
		Elements at = doc.getElementsByClass("profile-overview-content").select("span.org");
		int atual = -1;
		if (at != null)
		{	
			if (!at.text().equals("") && !at.text().equals(" "))
			{
				atual = 1;
			}
			else
			{
				atual = 0;
			}
		}
		return atual;
	}
	
	public static int extrairAnterior(Document doc)
	{
		Elements table = doc.getElementsByClass("profile-overview-content").select("table.extra-info");
		Elements a1 = table.select("tbody").select("tr");
		int anterior = 0  ; // 0 - nao declarado  1 - teve experiencia anterior   2 - nao teve experiencia anterior
		String texto = a1.text();
		
		if (texto.contains("Anterior"))
		{
			int posIni = texto.indexOf("Anterior");
			String ant="";
			if (texto.contains("Forma��o acad�mica"))
			{
				int posFin = texto.indexOf("Forma��o acad�mica");
				ant = texto.substring(posIni, posFin);
			
			}
			else
			{
				ant = texto.substring(posIni, texto.length()-1);
				
			}
			
			if (!ant.equals(""))
			{
				anterior = 1;
			}
			else
			{
				anterior = 2;
			}
		}
		else
		{
			anterior = 0;
		}
		
		return anterior;
	}
	
	public static int extrairConexoes(Document doc)
	{
		int conexoes = 0;
		
		Elements div_conexoes = doc.getElementsByClass("profile-overview-content").select("div.member-connections");
		
		if (div_conexoes!= null)
		{
			if (!div_conexoes.equals(""))
			{
				Elements strong_conexao = div_conexoes.select("strong");
				
				if (!strong_conexao.text().contains("+ de") 
						|| !strong_conexao.text().contains("+") || !strong_conexao.text().contains(""))
				{
					if (AllisDigito(strong_conexao.text()))
						conexoes = Integer.parseInt(strong_conexao.text());
				}
				else
				{
					String valor = strong_conexao.text().replace("+", " ").replace("de", " ").trim();
					if (AllisDigito(valor))
						conexoes = Integer.parseInt(valor);
				}
			}
		}
		
		return conexoes;
	}
	
	public static boolean AllisDigito(String str)
	{
		boolean teste = false;
		
		teste = (str.matches("[0-9]+"))? true: false;
		
		return teste;
	}
	
	public static String removeAcentos(String str) 
	{
		String s = Normalizer.normalize(str, Normalizer.Form.NFD);
		s = s.replaceAll("[^\\p{ASCII}]", "");
		return s;

	}
	
	public static boolean isAllLetrasAndSpaces(String myString)
	{
		boolean sohLetras = myString.matches("[a-zA-Z\\s]+");
		
		return sohLetras;
	}
		
	public static String getPath() 
	{
		return path;
	}

	public static void setPath(String path) 
	{
		ExtrairInformacoes.path = path;
	}
	
	
}
